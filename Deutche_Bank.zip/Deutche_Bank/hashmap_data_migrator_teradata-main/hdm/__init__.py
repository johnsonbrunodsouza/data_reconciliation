from providah.factories.package_factory import PackageFactory as pf


pf.fill_registry()