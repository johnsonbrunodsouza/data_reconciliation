# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import logging
import traceback
from datetime import datetime
from hdm.core.state_management.state_manager import StateManager

class Sink:
    @classmethod
    def _get_logger(cls):
        return logging.getLogger(cls.__name__)

    def __init__(self, **kwargs):
        self._logger = self._get_logger()
        self._logger.disabled = False
        self._entity: str = ""
        self._entity_filter: str = ""
        self._state_manager = kwargs['state_manager']
        self._state_manager_values = {}
        self._sink_name = ""
        self._is_running = False
        self._data_dict = kwargs['data_dict']
        self._last_iteration = kwargs['last_iteration']

    @property
    def is_running(self):
        return self._is_running

    def _insert_and_get_current_state(self) -> dict:
        self._correlation_id_in = self._data_dict['correlation_id_out']
        self._correlation_id_out = None
        self._state_manager.job_id = StateManager.generate_id()

        self._state_manager_values = self._state_manager.insert_state(
            source_entity=self._data_dict['sink_entity'],
            source_filter=None,
            sink_entity=self._original_table_name,
            sink_filter=self._entity_filter,
            action='sinking pre-push',
            correlation_id_in=self._correlation_id_in,
            correlation_id_out=self._correlation_id_out,
            status='in_progress',
            #sinking_start_time=datetime.utcnow()
            sinking_start_time=datetime.now()
        )
        return self._state_manager_values

    # update this to handle failures
    def _update_state(self, current_state) -> None:
        self._state_manager_values = self._state_manager.update_state(
            source_entity=current_state['source_entity'],
            source_filter=current_state['source_filter'],
            sink_entity=self._entity,
            sink_filter=self._entity_filter,
            action='sinking post-push',
            state_id=current_state['state_id'],
            correlation_id_in=current_state['correlation_id_in'],
            correlation_id_out=current_state['correlation_id_out'],
            status=current_state['status'],
            record_count=current_state['record_count'],
            sourcing_start_time=current_state['sourcing_start_time'],
            sourcing_end_time=current_state['sourcing_end_time'],
            sinking_start_time=current_state['sinking_start_time'],
            #sinking_end_time=datetime.utcnow(),
            sinking_end_time=datetime.now(),
            first_record_pulled=current_state['first_record_pulled'],
            last_record_pulled=current_state['last_record_pulled']
        )
        """
        for object in self._data_dict['objects'].keys(): 
            self._state_manager_values = self._state_manager.update_state(            
                action='sinking post-push',
                state_id=self._data_dict['objects'][object]['state_id'],               
                status=current_state_status,                
                sourcing_end_time=datetime.utcnow(),
                sinking_end_time=datetime.utcnow(),
                source_entity=object,
                source_filter=self._data_dict['objects'][object]['source_filter'],
                correlation_id_in=self._data_dict['objects'][object]['correlation_id_in'],
                correlation_id_out=self._data_dict['objects'][object]['correlation_id_out'],
                sink_entity = self._entity,
                sink_filter = self._entity_filter,
                first_record_pulled = self._data_dict['objects'][object]['first_record_pulled'],
                last_record_pulled = self._data_dict['objects'][object]['last_record_pulled'],
                sourcing_start_time = self._data_dict['objects'][object]['sourcing_start_time'],
                sinking_start_time = self._data_dict['objects'][object]['sourcing_start_time'],
                record_count = self._data_dict['objects'][object]['record_count']                
            )
            """

    def _update_first_record(self, last_watermark_value, firstrecord) -> None:  
        self._state_manager.source = {'name': 'teradata_source', 'type': 'TeradataSource'}                                 
        self._state_manager.sink = {'name': 's3_stg', 'type': 'S3Sink'}   
        self._state_manager.job_id = firstrecord['job_id']   
        self._state_manager_values = self._state_manager.update_state(            
            action=firstrecord['action'],
            state_id=firstrecord['state_id'],               
            status=firstrecord['status'],                
            sourcing_end_time=firstrecord['sourcing_end_time'],
            sinking_end_time=firstrecord['sinking_end_time'],
            source_entity=firstrecord['source_entity'],
            source_filter=firstrecord['source_filter'],
            correlation_id_in=firstrecord['correlation_id_in'],
            correlation_id_out=firstrecord['correlation_id_out'],
            sink_entity = firstrecord['sink_entity'],
            sink_filter = firstrecord['sink_filter'],
            first_record_pulled = firstrecord['first_record_pulled'],
            last_record_pulled = f"{self._watermark_column}~#${last_watermark_value}",
            sourcing_start_time = firstrecord['sourcing_start_time'],
            sinking_start_time = firstrecord['sinking_start_time'],
            record_count = firstrecord['record_count']                
        )
    def produce(self, **kwargs) -> None:
        raise NotImplementedError(f'Method not implemented for {type(self).__name__}.')
    
    def _insert_sinking_pre_push(self):
        self._state_manager.job_id = StateManager.generate_id()
        for object in self._data_dict['objects'].keys():            
            self._state_manager_values = self._state_manager.insert_state(
                source_entity = object,
                source_filter = None,
                action = 'sinking pre-push',
                status = 'in_progress', 
                correlation_id_in =  self._data_dict['objects'][object]['correlation_id'],
                correlation_id_out = None,
                sink_entity = self._entity ,
                sink_filter = self._entity_filter,
                #sourcing_start_time = datetime.utcnow(), 
                sourcing_start_time = datetime.now(), 
                sourcing_end_time = None, 
                #sinking_start_time = datetime.utcnow(), 
                sinking_start_time = datetime.now(), 
                sinking_end_time = None,
                first_record_pulled = None,
                last_record_pulled = None,
                record_count = self._data_dict['objects'][object]['record_count']                
            )
            for key in self._state_manager_values.keys():
                self._data_dict['objects'][object][key] = self._state_manager_values[key]

    def _run(self, **kwargs) -> None:
        # Set that it is running
        self._is_running = True

        # Get the current state
        file_name = kwargs.get("file_name", None)
        parent_file_name = kwargs.get("parent_file_name", None)
        source_filter = kwargs.get("source_filter", None)
        #if parent_file_name:
            # for chunk source where parent file name is the source_entity.
        #   current_state = self._get_current_state(entity=parent_file_name, entity_filter=source_filter)
        #else:
        #    current_state = self._get_current_state(entity=file_name, entity_filter=source_filter)

        #if not current_state:
        current_state = self._insert_and_get_current_state()
        try:
            kwargs['current_state'] = current_state
            #Removing s3 stuff     
            #self._insert_sinking_pre_push()
            self._set_data(**kwargs)
            current_state['status'] = 'success'
            #Removing s3 stuff
            current_state['record_count'] = self._data_dict['snowflake_record_count']            
            #current_state['record_count'] = 0
            self._logger.info("PUT DATA: Entity: %s; TotalRecords: %s",
                              self._entity,
                              current_state['record_count'] if current_state['record_count'] else "0"
                              )

        except Exception:
            current_state['status'] = 'failure'
            current_state['record_count'] = None
            self._error_handler(traceback.format_exc())
        finally:
            #Remove s3 stuff
            #self._update_state(current_state['status'])
            self._update_state(current_state)
            if self._last_iteration and current_state['status'] == 'success' and self._watermark_column:
                last_watermark_value = self._fetch_last_watermark_value()
                if last_watermark_value != "":
                    firstrecord = self._state_manager.get_first_record_for_table_in_curent_run(self._original_table_name)
                    self._update_first_record(last_watermark_value, firstrecord)
                
            # Set that it is no longer running
            self._is_running = False

    def _get_current_state(self, entity, entity_filter) -> dict:
        current_state = self._state_manager.get_current_state(entity, entity_filter)                    
        self._sink_name = current_state['sink_name']
        return current_state

    def _set_data(self, **kwargs) -> dict:
        raise NotImplementedError(f'Method not implemented for {type(self).__name__}.')

    def _error_handler(self, error: str) -> None:
        self._logger.exception("An error has occurred in Sink: %s", error)
