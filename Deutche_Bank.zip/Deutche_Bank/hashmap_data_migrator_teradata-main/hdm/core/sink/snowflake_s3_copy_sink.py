# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from hdm.core.dao.snowflake_s3_copy import SnowflakeS3Copy
from hdm.core.sink.snowflake_copy_sink import SnowflakeCopySink
import datetime
from hdm.core.utils.generic_functions import GenericFunctions


class SnowflakeS3CopySink(SnowflakeCopySink):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._dao = SnowflakeS3Copy(connection=kwargs['env']['env'], stage_directory=kwargs['env']['stage_directory'],
                                    stage_name=GenericFunctions.table_to_folder(kwargs['stage_name']), source_env=kwargs['env']['source_env'],
                                    iteration=kwargs['iteration'], s3object=kwargs['stage_name'].replace('.','_'))        

    def _generate_query_for_table_creation_for_cdc(self, table_name):
        getddl = f"select GET_DDL('table', '{table_name}');"
        return getddl

    def _get_columns(self, table_name):
        columnlist = []
        primarykeys = []
        with self._dao.get_only_connection as conn:
            mergecursor = conn.cursor()
            mergecursor.execute('show columns in table ' + table_name + ' ;')
            
            for column in mergecursor:
                columnlist.append(column[2])
            
            if not self._primarykeys == None and len(self._primarykeys) > 0:
                primarykeys = self._primarykeys            
            else:
                mergecursor.execute('show primary keys in ' + table_name + ' ;')
                for primarykey in mergecursor:
                    primarykeys.append(primarykey[4]) 
        
        return columnlist, primarykeys


    def _generate_query_for_merge(self, table_name, cdc_table):
        columnlist, primarykeys = self._get_columns(table_name)
                      
        if len(primarykeys) == 0:
            raise ValueError(f"No keys found on table {table_name} or on config table {self._keytablename}. Keys are mandatory for merge operation.")   
        
        mergequeries = []
        primarykeymatch = ""
        updatelist = ""
        insertlistcolumns = ""
        insertlistvalues = ""
        deletelistkeycolumns = ""
        deletekeymatch = ""
        columnnumber = 1
        for column in columnlist:
            if column in primarykeys:
                primarykeymatch = f"{primarykeymatch} {table_name}.{column} = {cdc_table}.{column} AND "
                deletekeymatch = f"{deletekeymatch} {table_name}.{column} = cdc.{column} AND "
                deletelistkeycolumns = f"{deletelistkeycolumns} {column}, "               
            else:                                     
                updatelist = f"{updatelist} {table_name}.{column} = {cdc_table}.{column},"

            insertlistcolumns = f"{insertlistcolumns} {column},"
            insertlistvalues = f"{insertlistvalues} {cdc_table}.{column},"
            columnnumber = columnnumber + 1
                
        primarykeymatch = primarykeymatch[0:-4]
        deletekeymatch = deletekeymatch[0:-4]
        updatelist = updatelist[0:-1]
        insertlistcolumns = insertlistcolumns[0:-1]
        insertlistvalues = insertlistvalues[0:-1]
        deletelistkeycolumns = deletelistkeycolumns[0:-2]

        if self._merge_mode.lower() in ["merge", "incremental"]:

            mergequery = f"MERGE INTO {table_name} " \
                         f"USING {cdc_table} " \
                         f"ON {primarykeymatch} " \
                         f"WHEN MATCHED THEN UPDATE SET {updatelist} " \
                         f"WHEN NOT MATCHED THEN INSERT ( {insertlistcolumns} ) VALUES ( {insertlistvalues} )" 
            
            mergequeries.append(mergequery)

        elif self._merge_mode.lower() == "deleteinsert":

            deletequery = f"DELETE FROM {table_name} " \
                          f"USING (SELECT DISTINCT {deletelistkeycolumns} FROM {cdc_table}) as cdc " \
                          f"WHERE {deletekeymatch}"
                          
            insertquery = f"INSERT INTO {table_name}({insertlistcolumns}) " \
                          f"SELECT {insertlistcolumns} FROM {cdc_table}"

            mergequeries.append(deletequery)
            mergequeries.append(insertquery)
        else:
            raise ValueError("Incorrect merge mode used. The values need to be in the list ['merge', 'deleteinsert']")

        return mergequeries

    def _generate_query(self, file_name, table_name) -> None:
        text = f"'.*{file_name}.*'"
        file_format = f"FILE_FORMAT = (TYPE = {self._file_format} FIELD_OPTIONALLY_ENCLOSED_BY = '\"' "
        if self._encoding != None:
            file_format = f"{file_format} ENCODING = {self._encoding}) " 
        else:
            file_format = f"{file_format} REPLACE_INVALID_CHARACTERS = TRUE) "

        self._query = f"COPY INTO {table_name} " \
                      f"FROM @{self._stage_name} " \
                      f"{file_format} " \
                      f"PATTERN = {text} " \
                      f"PURGE = TRUE "

    def _generate_query_for_max_watermark(self, table_name):
        return f"SELECT MAX({self._watermark_column}) FROM {table_name};"

    def _generate_query_for_record_count(self, table_name, stage_location):
        return f"select coalesce(sum(row_count),0) " \
               f"from table(information_schema.copy_history(table_name=>'{table_name}', start_time=> dateadd(hours, -0.5, current_timestamp())))" \
               f"where stage_location = '{stage_location}';"
