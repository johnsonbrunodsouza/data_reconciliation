from google.cloud import storage
import subprocess

def copy_hive_files_to_gcs(hdfs_source_path, gcs_destination_path):
    # HDFS path of the Hive table data
    #hdfs_source_path = f"/user/hive/warehouse/{hive_database}.db/{hive_table}"
    # GCS destination path
    #gcs_destination_path = f"gs://{gcs_bucket_path}/"

    # DistCp command to copy data from HDFS to GCS
    distcp_command = f"hadoop distcp {hdfs_source_path} {gcs_destination_path}"

    try:
        # Execute the DistCp command
        subprocess.run(distcp_command, shell=True, check=True)
        print("Hive files copied to GCS successfully!")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred while copying Hive files to GCS: {e}")