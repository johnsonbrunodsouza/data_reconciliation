import boto3
import os

from numpy import record
import logging
import traceback

class S3():
    @classmethod
    def _get_logger(cls):
        return logging.getLogger(cls.__name__)

    def __init__(self, **kwargs):
        self.__logger = self._get_logger()
        self.__s3_client = boto3.client('s3')
        self.__s3_resource = boto3.resource('s3')
        self.__bucketname = kwargs['bucket_name']
        self.__prefix = kwargs['prefix']
        self.__object_list = {}
    
    def getrecordcount(self, s3_key):
        recordcount = 0
        colsep = ','       
        sql_stmt = """SELECT count(*) FROM s3object S"""  
        req_fact = self.__s3_client.select_object_content(Bucket = self.__bucketname, Key = s3_key, ExpressionType = 'SQL',
                                                          Expression = sql_stmt, InputSerialization={'CSV': {}},
                                                          OutputSerialization = {'CSV': {'RecordDelimiter': os.linesep, 'FieldDelimiter': colsep}})
        for event in req_fact['Payload']:
            if 'Records' in event:
                rr=event['Records']['Payload'].decode('utf-8')
                for i, rec in enumerate(rr.split(os.linesep)):
                    if rec:
                        row=rec.split(colsep)
                        if row:
                            recordcount = row[0]
                            break
            break
        
        return recordcount
    
    def generate_record_count(self):
        self.__logger.info(f"Getting record counts from s3://{self.__bucketname}/{self.__prefix}")
        record_count = 0
        data_dict = {}
        data_dict['objects'] = {}
        data_bucket = self.__s3_resource.Bucket(self.__bucketname)
        for bucket_object in data_bucket.objects.filter(Prefix=self.__prefix):
            try:
                data_dict['objects'][f"{self.__bucketname}/{bucket_object.key}"] = {'record_count':self.getrecordcount(bucket_object.key) }
                
            except Exception:
                self.__logger.exception(f"Error fetching counts for : {self.__bucketname}/{bucket_object.key} - {traceback.format_exc()}")
                data_dict['objects'][f"{self.__bucketname}/{bucket_object.key}"] = {'record_count': 0 }

        for value in data_dict['objects'].values():
            record_count = record_count + int(value['record_count'])
        
        data_dict['record_count'] = record_count

        return data_dict

    