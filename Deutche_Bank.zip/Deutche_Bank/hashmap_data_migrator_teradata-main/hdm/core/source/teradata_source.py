# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import json
import os
from sys import stderr
import pandas as pd
import enum
import datetime
from jinjasql import JinjaSql
import subprocess
from sqlalchemy import true
import yaml
from hdm.core.query_templates.query_templates import QueryTemplates
from hdm.core.utils.project_config import ProjectConfig
from hdm.core.utils.generic_functions import GenericFunctions
from hdm.core.source.rdbms_source import RDBMSSource
from hdm.core.source.s3_source import S3
from hdm.core.dao.teradata import Teradata


class HashFunction(enum.Enum):
    STANDARD_HASH = "CRC32"


class TeradataSource(RDBMSSource):    
    def consume(self, **kwargs):
        self._logger.info("Retrieving data from %s", self.__table)
        return self._run(**kwargs)

    def __init__(self, **kwargs):        
        super().__init__(**kwargs)
        self._is_running = True
        self.__connection_choice = kwargs['workflow']['source']['conf']['env']
        self.__user = kwargs['conn_conf'][self.__connection_choice]['user']
        self.__pwd = kwargs['conn_conf'][self.__connection_choice]['password']
        self.__host = kwargs['conn_conf'][self.__connection_choice]['host']
        self.__s3role = kwargs['conn_conf'][kwargs['workflow']['sink']['conf']['source_env']]['s3_role']
        self.__region = kwargs['conn_conf'][kwargs['workflow']['sink']['conf']['source_env']]['region_name']
        self.__iteration = kwargs['iteration']        
        self.__table = kwargs['table']['table_name']
        self.__merge = False
        self.__incrementalload = False
        self.__last_iteration = kwargs['last_iteration']
        if kwargs['table']['cdc']['mode']:
            if kwargs['table']['cdc']['mode'].lower() != 'incremental' or (kwargs['table']['cdc']['mode'].lower() == 'incremental' and self.__last_iteration):
                self.__merge = True
            if kwargs['table']['cdc']['mode'].lower() == 'incremental':
                self.__incrementalload = True
        self.__year = kwargs['year']
        self.__month = kwargs['month']
        self.__watermark = kwargs['table']['watermark']       
        self._entity = self.__table
        self._entity_filter = kwargs['table']['watermark']['column']   
        self.__checksum = kwargs['table']['checksum']
        self.__tpt_path = kwargs['workflow']['source']['conf']['directorypath']
        self.__consumer_sessions = kwargs['workflow']['source']['conf']['consumersessions']
        self.__producer_sessions = kwargs['workflow']['source']['conf']['producersessions']
        #Overwrite if a different value is specified at a table level
        if 'consumersessions' in kwargs['table']:
            if kwargs['table']['consumersessions']:
                self.__consumer_sessions = kwargs['table']['consumersessions']

        if 'producersessions' in kwargs['table']:
            if kwargs['table']['producersessions']:
                self.__producer_sessions = kwargs['table']['producersessions']
        self.__shard_size = "250m"
        if 'shardsize' in kwargs['table']:
            if kwargs['table']['shardsize']:
                self.__shard_size = kwargs['table']['shardsize']
        self.__schema = kwargs['schema']
        self.__query_select_list = kwargs['query_select_list']
        self.__query = ""
        self.__manual_query = kwargs['table']['query']
        self.__compression = ""
        if 'compression' in kwargs['table']:
            if kwargs['table']['compression']:
                self.__compression = ".gz"
        self._source_name = kwargs['workflow']['source']['name']
        self._sink_name = kwargs['workflow']['sink']['name']
        self.__current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
        self.__directory = os.path.join(self.__tpt_path, self._source_name, GenericFunctions.table_to_folder(self.__table))        
        self.__tpt_script_path = os.path.join(self.__directory, self.__table[len(self.__table.split('.')[0]) + 1 :] + '_' + self.__current_timestamp + ".tpt")
        self.__tpt_logs = os.path.join(self.__directory, 'logs')        
        self.__tpt_log_path = os.path.join(self.__tpt_logs, self.__table[len(self.__table.split('.')[0]) + 1 :] + '_' + self.__current_timestamp + "_TPT.log")        
        self.__bucket_name = kwargs['conn_conf'][kwargs['workflow']['sink']['conf']['source_env']]['bucket_name']
        self.__s3_object = S3(bucket_name=self.__bucket_name, prefix=f"migration/{GenericFunctions.table_to_folder(self.__table)}/{self.__iteration}/{self.__table.replace('.','_')}")    
        self.__keytablename = ""
        self.__keytablenamecolumn = ""
        self.__keycolumn = ""
        if 'cdc' in kwargs['table']:
            if not kwargs['table']['cdc']['mode'] == None:
                self.__keytablename = kwargs['table']['cdc']['keytable']['tablename']
                self.__keytablenamecolumn = kwargs['table']['cdc']['keytable']['tablenamecolumn']
                self.__keycolumn = kwargs['table']['cdc']['keytable']['keycolumn']
        self.__year_month_iteration = kwargs['year_month_iteration']
        self.__year_iteration = kwargs['year_iteration']
        

    def _get_key_columns(self):        
        primarykeys = []
        
        if self.__keytablename != None:
            self._logger.info(f"Getting key columns from {self.__keytablename} for table {self.__table.split('.')[1]}")
            query = f"select {self.__keycolumn} " \
                    f"from {self.__keytablename} " \
                    f"where {self.__keytablenamecolumn} = '{self.__table.split('.')[1]}'"

            with Teradata(connection=self.__connection_choice).connection as conn:
                df = pd.read_sql(query, conn)
                primarykeys = df[self.__keycolumn].to_list()
        
        return primarykeys
    
    def _lines_that_contain(self, string, fp):
        return [line.rstrip().split(':')[2].strip() for line in fp if string in line][0]

    def _get_data(self, **kwargs):
        self.__build_query()
        self.__get_data_with_tpt()   
        #Removing s3 stuff     
        #data_dict = self.__s3_object.generate_record_count()
        data_dict = {}
        data_dict['sink_entity'] = f"s3://{self.__bucket_name}/migration/" \
                                   f"{GenericFunctions.table_to_folder(self.__table)}/{self.__iteration}/" 
                                   #f"{self.__table.replace('.','_')}"
        if self.__merge:
            data_dict['primarykeys'] = self._get_key_columns()
        else: 
            data_dict['primarykeys'] = []
        
        data_dict['record_count'] = 0
        
        with open(self.__tpt_log_path, "r") as fp:
            data_dict['record_count'] = self._lines_that_contain('Producer_Query_Detail: Total Rows Exported:', fp)
        
        return data_dict

    

    
    def __build_query_for_tpt_schema(self, **kwargs):
        query_template = QueryTemplates.teradata_schema_template
        params = {
            'table_name': self.__table[len(self.__table.split('.')[0]) + 1 :],
            'database_name': self.__table.split('.')[0]
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        query = query % bind_params
        return query

    def __build_tpt_script_for_s3(self) -> None:
        
        try:
            if not os.path.isdir(self.__directory):
                os.makedirs(self.__directory)   
            
            if not os.path.isdir(self.__tpt_logs):
                os.makedirs(self.__tpt_logs)   

            tptscript = f"DEFINE JOB EXPORT_{self.__table.replace('.','_')} \n" \
                        f"DESCRIPTION 'Exports {self.__table.replace('.','_')} data to S3 using EXPORT' \n" \
                        f"( \n" \
                        f"   DEFINE OPERATOR Consumer_File_Detail \n" \
                        f"   DESCRIPTION 'Defining a consumer operator for storing retrieved data to a file' \n" \
                        f"   TYPE DATACONNECTOR CONSUMER \n" \
                        f"   SCHEMA * \n" \
                        f"   ATTRIBUTES \n" \
                        f"   ( \n" \
                        f"       VARCHAR AccessModuleName = 'libs3axsmod.dll', \n" \
                        f"       VARCHAR AccessModuleInitStr = 'S3Bucket=\"{self.__bucket_name}\" S3Prefix=\"migration/{GenericFunctions.table_to_folder(self.__table)}/{self.__iteration}/\" S3DontSplitRows=\"True\" S3Object=\"{self.__table.replace('.','_')}{self.__compression}\" S3SinglePartFile=False S3MaxObjectSize={self.__shard_size} S3ConfigDir=\"{ProjectConfig.hdm_home()}/.aws\" S3Role=\"{self.__s3role}\" S3Region=\"{self.__region}\"', \n" \
                        f"       VARCHAR Format = 'Delimited', \n" \
                        f"       VARCHAR TextDelimiter=',', \n" \
                        f"       VARCHAR QuotedData='Yes' \n" \
                        f"   ); \n" \
                        f"   DEFINE SCHEMA Define_{self.__table.replace('.','_')}_Schema \n" \
                        f"   DESCRIPTION 'Defining a Schema to describe the structure of the output file' \n" \
                        f"   ( \n" \
                        f"   {self.__schema} \n" \
                        f"   ); \n" \
                        f"   DEFINE OPERATOR Producer_Query_Detail \n" \
                        f"   TYPE EXPORT \n" \
                        f"   SCHEMA Define_{self.__table.replace('.','_')}_Schema \n" \
                        f"   ATTRIBUTES \n" \
                        f"   ( \n" \
                        f"       VARCHAR UserName='{self.__user}', \n" \
                        f"       VARCHAR UserPassword='{self.__pwd}', \n" \
                        f"       VARCHAR SelectStmt ='{self.__query};', \n" \
                        f"       VARCHAR Tdpid='{self.__host}', \n" \
                        f"       INTEGER MaxSessions=6, \n" \
                        f"       INTEGER minsessions=2, \n" \
                        f"       INTEGER TenacityHours=2 \n" \
                        f"   ); \n" \
                        f"   APPLY \n" \
                        f"   TO OPERATOR( Consumer_File_Detail[{self.__consumer_sessions}] ) \n" \
                        f"   SELECT * FROM OPERATOR( Producer_Query_Detail[{self.__producer_sessions}] ); \n" \
                        f");"           
            
            with open(self.__tpt_script_path, 'w') as f:
                f.write(tptscript)
        except Exception:
            raise ValueError("Unable to write TPT script. Please check for errors...")  

    def __get_data_with_tpt(self, **kwargs):
        self._logger.info("Creating TPT script to fetch data")
        self.__build_tpt_script_for_s3()
        self._logger.info(f"Executing TPT script {self.__tpt_script_path}. TPT logs created at: {self.__tpt_log_path}")
        try:
            with open(self.__tpt_log_path, 'w') as logfile:
                subprocess.run(["tbuild","-f", self.__tpt_script_path, "-j", f"{GenericFunctions.table_to_folder(self.__table)}_{self.__iteration}"], check=True, stdout=logfile, stderr=subprocess.STDOUT, text=True)
        except Exception as e:            
            raise ValueError("Error in running TPT script: " + str(e))        
    
    def __build_query(self) -> None:
        """
        builds query.
        checksum_methods:
        default method: generates random numbers as checksum value
        Returns: none
        """
        if self.__manual_query != None:
            self.__query = self.__manual_query
            return

        _checksum_flag, _query_limit, _watermark_flag, _last_record_pulled_flag, _last_record_pulled, _checksum_function, \
            _checksum_column, _watermark_column, _watermark_offset, _watermark_offset_flag = (None,) * 10

        # Checksum
        if self.__checksum and self.__checksum['function'] and self.__checksum['column']:
            _checksum_flag = 'CRC32' if self.__checksum['function'].lower() == HashFunction.STANDARD_HASH.value else ''
            _checksum_function = self.__checksum['function'].lower()
            _checksum_column = self.__checksum['column'].lower()

        # Watermark
        if self.__watermark and self.__watermark['column']:
            _watermark_flag, _watermark_column = True, self.__watermark['column']

            if self.__watermark['offset'] and self.__watermark['offset'] != "":
                _watermark_offset_flag, _watermark_offset = True, self.__watermark['offset']

            if self._last_record_pulled:
                for key_value in self._last_record_pulled.split(','):
                    if self.__watermark['column'] == key_value.split("~#$")[0]:
                        _last_record_pulled_flag, _last_record_pulled = True, key_value.split("~#$")[1]
                        break

        # Query_limit
        if ProjectConfig.query_limit():
            _query_limit = ProjectConfig.query_limit()

        query_template = QueryTemplates.teradata_source_template
        params = {
            'table_name': self.__table,
            'watermark_flag': _watermark_flag,
            'watermark_column': _watermark_column,
            'watermark_offset_flag': _watermark_offset_flag,
            'watermark_offset': _watermark_offset,
            'checksum_function': _checksum_function,
            'checksum_column': _checksum_column,
            'last_record_pulled_flag': _last_record_pulled_flag,
            'last_record_pulled': _last_record_pulled,
            'query_limit': _query_limit,
            'merge_flag': self.__merge,
            'year_value': self.__year,
            'month_value': self.__month,
            'year_month_iteration_flag': self.__year_month_iteration,
            'query_select_list': self.__query_select_list,
            'year_iteration_flag': self.__year_iteration,
            'incrementalload': self.__incrementalload
        }
        j = JinjaSql(param_style='pyformat')
        query, bind_params = j.prepare_query(query_template, params)
        self.__query = query % bind_params
