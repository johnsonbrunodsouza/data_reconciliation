import sys
sys.path.append(r'C:\NTTDATA\Deutche_Bank\hashmap_data_migrator_teradata-main')