from datetime import datetime


class GenericFunctions:

    @classmethod
    def folder_to_table(cls, name):
        return name.replace("__", ".")

    @classmethod
    def table_to_folder(cls, name):
        # the below is for Hive as data source. Hive don't have schemas
        if name.find(".") < 0:
            name = "DEFAULT." + name
        return name.replace(".", "__")

    @classmethod
    def string_to_datetime(cls, str_date):
        return datetime.strptime(str_date, '%Y-%m-%d %H:%M:%S.%f')

    @classmethod
    def datetime_to_string(cls, date_obj):
        return date_obj.strftime('%Y-%m-%d %H:%M:%S.%f')
