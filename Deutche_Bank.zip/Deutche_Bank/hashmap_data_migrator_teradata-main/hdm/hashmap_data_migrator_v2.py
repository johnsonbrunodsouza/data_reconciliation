import sys
sys.path.append(r'C:\NTTDATA\Deutche_Bank\hashmap_data_migrator_teradata-main')
from hdm.core.dao.snowflake import Snowflake
from hdm.core.dao.teradata import Teradata
from hdm.core.utils.project_config import ProjectConfig
from hdm.core.source.teradata_source import TeradataSource
from hdm.core.state_management.state_manager import StateManager
#from hdm.core.state_management.bigquery_state_manager import SnowflakeStateManager
from hdm.core.error.hdm_error import HDMError
from hdm.core.query_templates.query_templates import QueryTemplates
import yaml
import pandas as pd
import numpy as np
import click
import os
from hdm.core.utils.parse_config import ParseConfig
from hdm.core.utils.project_config import ProjectConfig
import logging.config
import uuid
import datetime 
from jinjasql import JinjaSql
from hdm.core.utils.generic_functions import GenericFunctions
import traceback

from argparse import ArgumentParser, ArgumentTypeError
from hdm.core.utils import file_utils
from hdm.core.cataloger import Cataloger
from providah.factories.package_factory import PackageFactory as providah_pkg_factory
import platform
from hdm.core.dao.bigquery import BigQuery
import uuid

statemanager = "BigQueryStateManager"
source = "Hive"
target = "BigQuery"
import paramiko

default_log_settings = "/core/logs/log_settings.yml"

import subprocess

# @click.command()
# @click.option('-m', '--manifest', type=str, help='path of manifest to run')
# @click.option('-l', '--log_settings', type=str, default=default_log_settings, help="log settings path")
# @click.option('-e', '--env', default="prod", type=str, help="environment to take connection information from in hdm_profiles.yml")
# @click.option('-s', '--data_staging', type=str, help="path where data files will be staged locally")    
def bq_load(df_table_summary,df_table_details,gcs_bucket):
    command = ['bq load --source_format=PARQUET --hive_partitioning_mode=CUSTOM --hive_partitioning_source_uri_prefix=gs://tpcds-benchmarking-data/migrator/books/{​category:STRING}​/{​publication_year:INT64}​/ HDM_TEST.BOOKS "gs://tpcds-benchmarking-data/migrator/books/*"']
    
    data_type_map = { 
        "int64": "int|tinyint|smallint|bigint|integer",
        "numeric":"decimal",
        "float64":"double|float",
        "bool":"boolean",
        "string":"char|string|varchar",
        "bytes":"binary",
        "date": "date",
        "datetime":"timestamp",
        "array":"array",
        "struct":"struct|maps|union"}
    
    for index in df_table_summary.index:
        table_name = df_table_summary['TableName'][index]
        database =  df_table_summary['DatabaseName'][index]
        partition_column = df_table_summary['PartitionColumn'][index]

        partitions_lst = []
        if partition_column is not None:
            partitions = str(partition_column).split(',')

            for partition in partitions:
                column_type = df_table_details[(df_table_details['DATABASE_NAME']==database) &
                                                (df_table_details['TABLE_NAME']==table_name) &
                                                (df_table_details['COLUMN_NAME']==partition)]
                column_type = column_type['COLUMN_TYPE'].to_list()[0]

                for target_type, source_type in data_type_map.items():
                    for s_type in source_type.split('|'):
                        if s_type == column_type:
                            partitions_lst.append('{' + f'{partition}:{target_type}' + '}')


        source_format = '--source_format=PARQUET'
        hive_partitioning = '--hive_partitioning_mode=CUSTOM'

        if len(partitions_lst)==0:
            hive_partitioning_source_uri_prefix = f'{gcs_bucket}{database}.db/{table_name}/'
            command = f'bq load {source_format}  {database}.{table_name} "{gcs_bucket}{database}.db/{table_name}/*"'
        else:
            hive_partitioning_source_uri_prefix = f'{gcs_bucket}{database}.db/{table_name}/{"/".join(partitions_lst)}'
            command = f'bq load {source_format}  {hive_partitioning} --hive_partitioning_source_uri_prefix="{hive_partitioning_source_uri_prefix}" {database}.{table_name} "{gcs_bucket}{database}.db/{table_name}/*"'

        print(command)

        run_id = uuid.uuid4().hex
        current_date = datetime.datetime.now()
        
        SM_summary_query = f"insert into HDM.STATE_MANAGER_SUMMARY values ('{run_id}','','{database}.{table_name}',0,0,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP())"
        SM_query = f"insert into HDM.STATE_MANAGER values ('','{run_id}','','','','Data transfer','Initiated','bigquery','bucket','bigquery','table','','','','','','','',CURRENT_TIMESTAMP(),null,null,null,CURRENT_TIMESTAMP(),null,CURRENT_TIMESTAMP(),'')"
        execute_update([SM_query,SM_summary_query])

        try:
            subprocess.run(command, check=True, shell=True, stderr=subprocess.STDOUT, text=True)
            print("Data loaded successfully into BigQuery.")
            SM_query = f"insert into HDM.STATE_MANAGER values ('','{run_id}','','','','Data transfer','Completed','bigquery','bucket','bigquery','table','','','','','','','',null,CURRENT_TIMESTAMP(),null,null,CURRENT_TIMESTAMP(),null,CURRENT_TIMESTAMP(),'')"
            execute_update([SM_query])
        except subprocess.CalledProcessError as e:
            print(f'Exception occured. {e}')
            print("Failed to load data into BigQuery.")

def setup_ssh_client():
    #hadoop_server = 'ec2-3-236-147-154.compute-1.amazonaws.com'#'172.31.70.212' SHANIT's    
    hadoop_server = 'ec2-18-206-238-35.compute-1.amazonaws.com' # Aist's EMR    
    host = hadoop_server    
    hdfs_username = 'hadoop'    
    key_path = 'C:\\NTTDATA\\Deutche_Bank\\hdfs-hive-key-pair-2.pem'    
    print("establishing ssh connection....")    
    client = paramiko.client.SSHClient()
    client.load_system_host_keys()    
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    home = os.path.expanduser("~")
    ret = os.path.exists(os.path.join(home, key_path))
    if not ret:
        print("Unable to locate pem key, upload aborted....")
        return None    

    private_key = paramiko.RSAKey.from_private_key_file(key_path)
    try:
        client.connect(hostname=host, username=hdfs_username, pkey=private_key)
        #print(f"{'-' * 25}​\n\tSSH_client connected\n{​'_' * 25}​")
    except Exception as ex:
        #print(f"##### EXCEPTION ##########\n\t :::::::{​ex}​:::::::::")
        print("KONNECTION MAADI")
    
    distcp_cmd = 'hadoop distcp /user/hive/warehouse/hdm_test.db/books gs://tpcds-benchmarking-data/migrator/'
    stdin, stdout, stderr = client.exec_command(distcp_cmd) #'hadoop fs -ls /')
    #print(f"\n\t{​'_' * 65}​\n THE COMMAND => {​distcp_cmd}​ \n\tSTD-IN=\"{​stdin}​\" \n\t{​'-' * 55}​\n \tSTD-OUT==> \"{​stdout}​\"\n\t{​'-' * 55}​\n\tSTD-ERROR=\"{​stderr}​")
    for line in stdout:
        print('... ' + line.strip('\n'))

    return client
    #print("hello world")

def hadoop_to_gcs_transfer(hadoop_server, hdfs_username,key_path,database, tablename, gcs_bucket):
    try:
        print("establishing ssh connection....")    
        client = paramiko.client.SSHClient()
        client.load_system_host_keys()    
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        home = os.path.expanduser("~")
        ret = os.path.exists(os.path.join(home, key_path))
        if not ret:
            print("Unable to locate pem key, upload aborted....")
            return None    

        private_key = paramiko.RSAKey.from_private_key_file(key_path)
        client.connect(hostname=hadoop_server, username=hdfs_username, pkey=private_key)

        gcs_bucket = f'{gcs_bucket}{database}.db/'
        if database=='default':
            distcp_cmd = f'hadoop distcp /user/hive/warehouse/{tablename} {gcs_bucket}{tablename}'
        else:
            distcp_cmd = f'hadoop distcp /user/hive/warehouse/{database}.db/{tablename} {gcs_bucket}{tablename}'

        run_id = uuid.uuid4().hex
        current_date = datetime.datetime.now()
        
        SM_summary_query = f"insert into HDM.STATE_MANAGER_SUMMARY values ('{run_id}','','{database}.{tablename}',0,0,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP())"
        SM_query = f"insert into HDM.STATE_MANAGER values ('','{run_id}','','','','Data transfer','Initiated','hive','files','bigquery','bucket','','','','','','','',CURRENT_TIMESTAMP(),null,null,null,CURRENT_TIMESTAMP(),null,CURRENT_TIMESTAMP(),'')"
        execute_update([SM_query,SM_summary_query])
        stdin, stdout, stderr = client.exec_command(distcp_cmd)
        print("Response:")
        res = [line for line in stdout]
        print(f'*** Stdout: {res}')
        
        res = [line for line in stderr]
        SM_query = f"insert into HDM.STATE_MANAGER values ('','{run_id}','','','','Data transfer','Completed','hive','files','bigquery','bucket','','','','','','','',null,CURRENT_TIMESTAMP(),null,null,CURRENT_TIMESTAMP(),null,CURRENT_TIMESTAMP(),'')"
        execute_update([SM_query])
        
        #print(f'*** Stderr: {res}')

        return True
    except Exception as ex:
        print(f'Exception occured while copying file. Exception:{ex}')
        return False

def hadoop_to_gcs_transfer_v0(hadoop_server, hdfs_username,key_path,database, tablename, gcs_bucket):
    try:
        print("establishing ssh connection....")    
        client = paramiko.client.SSHClient()
        client.load_system_host_keys()    
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        home = os.path.expanduser("~")
        ret = os.path.exists(os.path.join(home, key_path))
        if not ret:
            print("Unable to locate pem key, upload aborted....")
            return None    

        private_key = paramiko.RSAKey.from_private_key_file(key_path)
        client.connect(hostname=hadoop_server, username=hdfs_username, pkey=private_key)

        gcs_bucket = f'{gcs_bucket}{database}.db/'
        if database=='default':
            distcp_cmd = f'hadoop distcp /user/hive/warehouse/{tablename} {gcs_bucket}{tablename}'
        else:
            distcp_cmd = f'hadoop distcp /user/hive/warehouse/{database}.db/{tablename} {gcs_bucket}{tablename}'
        
        print(distcp_cmd)
        stdin, stdout, stderr = client.exec_command(distcp_cmd)
        print("Response:")
        res = [line for line in stdout]
        print(f'*** Stdout: {res}')
        
        res = [line for line in stderr]
        #print(f'*** Stderr: {res}')

        return True
    except Exception as ex:
        print(f'Exception occured while copying file. Exception:{ex}')
        return False

def build_parser():
    parser = ArgumentParser(prog="hdm")

    parser.add_argument("-r", "--run", type=str, required=True, choices=['catalog'], help="'catalog'")
    parser.add_argument("-s", "--source", type=str, required=True,
                        help="Name of any one of sources configured in hdc.yml")
    parser.add_argument("-d", "--destination", type=str,
                        help="Name of any one of destinations configured in hdc.yml")
    parser.add_argument("-c", "--app_config", type=str,
                        help="Path to application config (YAML) file if other than default")
    parser.add_argument("-l", "--log_settings", type=str, help="Path to log settings (YAML) file if other than default")

    return parser

def start_here():
    hdc_parser = build_parser()
    cli_args = hdc_parser.parse_args()

    try:
        app_config: dict = file_utils.get_app_config(cli_args.app_config)

        if cli_args.log_settings is not None:
            logging.config.dictConfig(file_utils.yaml_parser(yaml_file_path=cli_args.log_settings))
        else:
            logging.config.dictConfig(file_utils.yaml_parser(yaml_file_path=file_utils.get_default_log_config_path()))

        try:
            cataloger: Cataloger = providah_pkg_factory.create(key='Cataloger',
                                                                library='hdm',
                                                                configuration={
                                                                    'source': cli_args.source,
                                                                    'app_config': cli_args.app_config})

            df_catalog = cataloger.obtain_catalog()
            df_table_details = df_catalog[0]
            df_table_summary = df_catalog[1]

            ############################
            ###### configurations ######
            ############################
            gcs_bucket = 'gs://tpcds-benchmarking-data/migrator/'
            hadoop_server = 'ec2-18-206-238-35.compute-1.amazonaws.com' # Aist's EMR
            hdfs_username = 'hadoop'
            key_path = 'C:\\NTTDATA\\Deutche_Bank\\hdfs-hive-key-pair-2.pem'

            for index in df_table_summary.index:
                tablename = df_table_summary['TableName'][index]
                database =  df_table_summary['DatabaseName'][index]
                status = hadoop_to_gcs_transfer(hadoop_server,hdfs_username,key_path,database, tablename, gcs_bucket)
                print(f"***Load status of {database}.{tablename} : {status}")


            bq_load(df_table_summary,df_table_details,gcs_bucket)

        except HDMError as hde:
            print(hde)
        
    except ArgumentTypeError as err:
        hdc_parser.print_usage()
        raise HDMError(message=err)

    except RuntimeError as err:
        raise HDMError(message=err)

def run(manifest, log_settings, env, data_staging):    
    os.environ['HDM_ENV'] = env
    if log_settings == default_log_settings:
        log_settings = os.path.abspath(os.path.dirname(__file__) + default_log_settings)

    log_setting_values = ParseConfig.parse(config_path=log_settings)
    
    os.environ['HDM_MANIFEST'] = manifest
    os.environ['HDM_DATA_STAGING'] = data_staging
    with open(f"{ProjectConfig.hdm_home()}/{ProjectConfig.profile_path()}", 'r') as stream:
        conn_conf = yaml.safe_load(stream)[ProjectConfig.hdm_env()]

    with open(manifest, 'r') as stream:
        workflow = yaml.safe_load(stream)
   
    run_id = uuid.uuid4().hex

    for table in workflow['source']['conf']['scenarios']:  
        try:            
            current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
            logpath = os.path.join(workflow['source']['conf']['directorypath'], 
                                workflow['source']['name'], 
                                GenericFunctions.table_to_folder(table['table_name']), 'logs',
                                table['table_name'][len(table['table_name'].split('.')[0]) + 1:] + '_' + current_timestamp + "_Process.log")
                                        
            if not os.path.isdir(os.path.dirname(logpath)):
                os.makedirs(os.path.dirname(logpath))   

            log_setting_values['handlers']['file']['filename'] = logpath
            logging.config.dictConfig(log_setting_values)
            logger = logging.getLogger('__main__')
            logger.disabled = False
            last_iteration = False
            iterations = 1 
            year_month_iteration = False
            year_iteration = False
            last_watermark_year = 0
            last_watermark_month = 0
            df = pd.DataFrame()
            stringsuppercase = False
            
            logger.info(f"Initiating export for {table['table_name']}")
            if not table['location']:
                if (not table['cdc']['mode'] or table['cdc']['mode'].lower() == 'incremental') and table['watermark']['column']:
                    logger.info("Building Query for table size")
                    query = build_query_for_sizing(table['table_name'], conn_conf[workflow['source']['conf']['env']]['database'])
                    with Teradata(connection=workflow['source']['conf']['env']).connection as conn:
                        df_size = pd.read_sql(query, conn)
                        if str(df_size.iloc[0, 3]) != 'Full':
                            if str(df_size.iloc[0, 3]) == 'Year':
                                year_iteration = True
                            else:
                                year_month_iteration = True

                            if table['cdc']['mode'] != None and table['cdc']['mode'].lower() == 'incremental':   
                                with Snowflake(connection=workflow['sink']['conf']['env']).connection as snowconn:
                                    cursor = snowconn.cursor()
                                    last_iteration_query = build_query_for_max_watermark(table['table_name'], table['watermark']['column'])
                                    last_watermark_year, last_watermark_month = cursor.execute(last_iteration_query).fetchone()
                                    cursor.close()
                            logger.info("Building Query for iterations")
                            query = build_query_for_iterations(table['table_name'], table['watermark']['column'],str(df_size.iloc[0, 3]), last_watermark_year, last_watermark_month, table['cdc']['mode'])
                            
                            df = pd.read_sql(query, conn)
                            iterations = df.shape[0]
                                
                        else:
                            df = pd.DataFrame()
                            year_month_iteration = False
                            year_iteration = False
                            
            if 'stringsuppercase' in workflow['source']['conf']:
                stringsuppercase = workflow['source']['conf']['stringsuppercase']

            if 'stringsuppercase' in table:
                stringsuppercase = table['stringsuppercase']
            logger.info(f"Config picked: year_month_iteration -> {str(year_month_iteration)}, year_iteration -> {str(year_iteration)}, stringsuppercase -> {stringsuppercase}")           
            # Code for split, insert the iterations values in STATE_MANAGER_SUMMARY
            logger.info(f"Total number of iterations: {str(iterations)}")
            logger.info(f"Insert iterations into STATE_MANAGER_SUMMARY")
            with Snowflake(connection=workflow['state_manager']['conf']['connection']).connection as snowconn:
                cursor = snowconn.cursor()
                summary_table_query = build_query_for_summary_table(run_id, manifest, table['table_name'], df.shape[0])
                cursor.execute(summary_table_query)
                cursor.close()

            logger.info(f"Build schema for table {table['table_name']}")
            schema, query_select_list = build_schema_for_table(table['table_name'], workflow, stringsuppercase)         
            
            for iteration in np.arange(iterations):
                if iteration == iterations - 1:            
                    last_iteration = True
                year = '0'
                month = '0'
                if df.shape[0] > 0:
                    year = str(df.iloc[iteration, 0])
                    month = str(df.iloc[iteration, 1])
                state_manager = generate_state_manager(workflow, manifest, run_id, logger)   
                teradataobj = TeradataSource(workflow=workflow, conn_conf=conn_conf, table=table, 
                                            iteration=f"{current_timestamp}_Iteration_{str(iteration)}", 
                                            state_manager= state_manager, schema = schema, query_select_list = query_select_list, 
                                            year = year, month = month, year_month_iteration = year_month_iteration, year_iteration = year_iteration,
                                            last_iteration = last_iteration)
                ret = teradataobj.consume()
                #state_manager.source = {'name': 's3_stg', 'type': 'S3Source'}                                 
                #state_manager.sink = {'name': 's3_stg', 'type': 'SnowflakeS3CopySink'}     
                #snowflakeobj = SnowflakeS3CopySink(env=workflow['sink']['conf'], stage_name=table['table_name'], 
                #                                   iteration=f"{current_timestamp}_Iteration_{str(iteration)}", 
                #                                   state_manager= state_manager, data_dict = ret, table = table, 
                #                                   last_iteration = last_iteration)
                #snowflakeobj.produce()
        except ValueError as Argument:
            error_handler(logger, Argument)
        except Exception:
            error_handler(logger, traceback.format_exc())

def user_home_directory():
    userhome = ""
    if platform.system().lower() != 'windows':
        userhome = os.getenv('HOME')
    else:
        userhome = os.getenv('USERPROFILE')
    return userhome

def create_manifest(tableconfigs):
    manifest = {}
    current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
    hdm_dir = os.path.join(user_home_directory(), ".hashmap_data_migrator")
    hdm_archive = os.path.join(user_home_directory(), ".hashmap_data_migrator", "Archive")
    if not os.path.isdir(hdm_dir):
        os.makedirs(hdm_dir) 
    if not os.path.isdir(hdm_archive):
        os.makedirs(hdm_archive)
    
    manifest['state_manager'] = {}
    manifest['state_manager']['name'] = 'state_manager'
    manifest['state_manager']['type'] = statemanager
    manifest['state_manager']['conf'] = {}
    manifest['state_manager']['conf']['connection'] = 'state_manager'

    manifest['source'] = {}
    manifest['source']['name'] = f"{source.lower()}_source"
    manifest['source']['type'] = "HiveSource"
    manifest['source']['conf'] = {}
    manifest['source']['conf']['env'] = source.lower()
    manifest['source']['conf']['directorypath'] = "C:/NTTDATA/Accelerators/hdm_dev"
    manifest['source']['conf']['scenarios'] = []
    for key in tableconfigs.keys():
        for table in tableconfigs[key]:
            if table['exportornot'] == "Export":                
                tablemigrationconfig = {}
                for tableconfig in table.keys():
                    if tableconfig != 'cdcmode':
                        tablemigrationconfig[tableconfig] = table[tableconfig]
                tablemigrationconfig['project'] = key


                manifest['source']['conf']['scenarios'].append(tablemigrationconfig)
    
    manifest['sink'] = {}
    manifest['sink']['name'] = f"{target.lower()}_sink"
    manifest['sink']['type'] = "SnowflakeGCSCopySink"
    manifest['sink']['conf'] = {}
    manifest['sink']['conf']['env'] = target.lower()
    manifest['sink']['conf']['source_env'] = source.lower()
    manifest['sink']['conf']['file_format'] = 'csv'
    manifest['sink']['conf']['stage_name'] = ''
    manifest['sink']['conf']['stage_directory'] = ''
    
    with open(os.path.join(hdm_dir, f"hdm_manifest_{current_timestamp}.yml"), 'w') as outfile:
        yaml.dump(manifest, outfile, default_flow_style=False)

    return str(os.path.join(hdm_dir, f"hdm_manifest_{current_timestamp}.yml")).replace("\\","/")


def tranfer_hive_table(gcs_bucket, tablename, hdfs_location):
    gcs_destination_path = f'gs://{gcs_bucket}/{tablename}/'
    print(f"HDFS source path is [{hdfs_location}]")
    
    distcp_command = f"hadoop distcp {hdfs_location} {gcs_destination_path}"

    try:
        # Execute the DistCp command
        subprocess.run(distcp_command, shell=True, check=True)
        print("Hive files copied to GCS successfully!")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred while copying Hive files to GCS: {e}")

def generate_state_manager(data_link_config: dict, manifest_name: str, run_id, logger) -> StateManager:
    state_manager = SnowflakeStateManager(configuration=data_link_config['state_manager'])
    if not isinstance(state_manager, StateManager):
        error = f'State manager {type(state_manager)} is not a StateManager.'
        logger.error(error)
        raise HDMError(error)

    state_manager.run_id = run_id
    state_manager.job_id = StateManager.generate_id()
    state_manager.manifest_name = manifest_name
    state_manager.source = {
        'name': data_link_config['source']['name'],
        'type': data_link_config['source']['type'],
    }
    state_manager.sink = {
        'name': 's3_stg',
        'type': 'S3Sink',
    }

    return state_manager

def build_query_for_summary_table(run_id, manifest, table_name, export_iterations):
    query_template = QueryTemplates.snowflake_summary_table_insert
    params = {
        'run_id': run_id,
        'manifest': manifest,
        'table_name': table_name,
        'export_iterations': export_iterations if export_iterations != 0 else export_iterations + 1,
        'create_date': str(datetime.datetime.now()),
        'update_date': str(datetime.datetime.now()),
        'summary_table': ProjectConfig.state_manager_summary_table_name()
    }
    j = JinjaSql(param_style='pyformat')
    query, bind_params = j.prepare_query(query_template, params)
    query = query % bind_params
    return query

def build_query_for_sizing(table_name, database_name):
    query_template = QueryTemplates.teradata_fetch_sizing_for_table
    params = {
        'table_name': table_name.split('.')[1],
        'database_name': database_name
    }
    j = JinjaSql(param_style='pyformat')
    query, bind_params = j.prepare_query(query_template, params)
    query = query % bind_params
    return query

def build_query_for_iterations(table_name, watermark_column, iteration, last_watermark_year, last_watermark_month, cdcmode):
    query_template = QueryTemplates.teradata_fetch_iterations_new
    params = {
        'table_name': table_name,
        'watermark_column': watermark_column,
        'iteration': iteration,
        'last_watermark_year': last_watermark_year,
        'last_watermark_month': last_watermark_month,
        'cdcmode': cdcmode
    }
    j = JinjaSql(param_style='pyformat')
    query, bind_params = j.prepare_query(query_template, params)
    query = query % bind_params
    return query

def build_query_for_max_watermark(table_name, watermark_column):
    query_template = QueryTemplates.snowflake_fetch_max_watermark_values
    params = {
        'table_name': table_name,
        'watermark_column': watermark_column
    }
    j = JinjaSql(param_style='pyformat')
    query, bind_params = j.prepare_query(query_template, params)
    query = query % bind_params
    return query

def build_query_for_tpt_schema(table):
    query_template = QueryTemplates.teradata_schema_template
    params = {
        'table_name': table.split('.')[1],
        'database_name': table.split('.')[0]
    }
    j = JinjaSql(param_style='pyformat')
    query, bind_params = j.prepare_query(query_template, params)
    query = query % bind_params
    return query

def build_schema_for_table(table, workflow, stringsuppercase):
    try:
        with Teradata(connection=workflow['source']['conf']['env']).connection as conn:               
            df = pd.read_sql(build_query_for_tpt_schema(table), conn)
            
        schema = ""
        query_select_list = ""
        for index, row in df.iterrows():
            schema = schema + f"    \"{row['ColumnName']}\" {row['ColumnDataType']}, \n"
            if row['ColumnType'] == "CV":
                if stringsuppercase:
                    query_select_list = query_select_list + f"UPPER(TRIM(\"{row['ColumnName']}\")), "
                else:
                    query_select_list = query_select_list + f"TRIM(\"{row['ColumnName']}\"), "
            elif row['ColumnType'] == "CF":
                if stringsuppercase:
                    query_select_list = query_select_list + f"UPPER(RTRIM(LTRIM(\"{row['ColumnName']}\"))), "
                else:
                    query_select_list = query_select_list + f"RTRIM(LTRIM(\"{row['ColumnName']}\")), "
            elif row['ColumnType'] == "N" and row['ColumnDataType'] == "NUMBER(38,0)":
                query_select_list = query_select_list + f"CAST(\"{row['ColumnName']}\" AS {row['ColumnDataType']}), "
            else:
                query_select_list = query_select_list + f"\"{row['ColumnName']}\", "
        return schema[:-3], query_select_list[:-2]
    except Exception:        
        raise ValueError("Unable to connect to Teradata source. Please check if source is up. Check the configuration: %s" % workflow['source']['conf']['env'])        

def error_handler(logger, exception_message: str) -> None:
    error_message = f"Error occurred in Source: {exception_message}"
    logger.exception(error_message)

def execute_update(sql_ddl_list):
        ### dao object is not being as it does not have query() method
        from google.cloud import bigquery
        import yaml
        import os
        from pathlib import Path

        yaml_file_path = Path.home() / '.hdc' / 'profile.yml'
        
        service_account_key_path = ''
        project_id = ''
        with open(yaml_file_path, 'r') as stream:
            config = yaml.safe_load(os.path.expandvars(stream.read()))
            service_account_key_path = config['bigquery']['client_service_json'].split('.json')[0] + '.json' # this is because path is appended with datetime. need to fix that
            project_id = config['bigquery']['dataset']

       
        #service_account_key_path = r"C:\NTTDATA\Deutche_bank\bigquery-eval-hd1341-f4215fb67922.json"
        #project_id = "bigquery-eval-hd1341"
        client = bigquery.Client.from_service_account_json(service_account_key_path, project=project_id)
        

        # for dataset in datasets:
        #     client.create_dataset(dataset.lower(),exists_ok=True)

        for create_query in sql_ddl_list:
            create_query = create_query
            query = create_query
            print(create_query)
            try:
                client.query(create_query)
            except Exception as e:
                print(f"Could not not execute SQL: [{query}]")
                print(f'Reason: [{e}]')

if __name__ == "__main__":
    #run()
    start_here()