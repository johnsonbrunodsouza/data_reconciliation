import paramiko
import os

def setup_ssh_client():
    hadoop_server = 'ec2-3-236-147-154.compute-1.amazonaws.com'#'172.31.70.212' SHANIT's
    hadoop_server = 'ec2-18-206-238-35.compute-1.amazonaws.com' # Aist's EMR
    host = hadoop_server
    hdfs_username = 'hadoop'
    key_path = r'C:\NTTDATA\Deutche_Bank\hdfs-hive-key-pair-2.pem'
    print("establishing ssh connection....")
    client = paramiko.client.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    home = os.path.expanduser("~")
    ret = os.path.exists(os.path.join(home, key_path))
    if not ret:
        print("Unable to locate pem key, upload aborted....")
        return None

    private_key = paramiko.RSAKey.from_private_key_file(key_path)
    try:
        client.connect(hostname=host, username=hdfs_username, pkey=private_key)
        print(f"{'-' * 25}\n\tSSH_client connected\n{'_' * 25}")
    except Exception as ex:
        print(F"##### EXCEPTION ##########\n\t :::::::{ex}:::::::::")

    print("KONNECTION PZHALA")
    stdin, stdout, stderr = client.exec_command('hadoop fs -ls /')
    print(
        f"\n\t{'_' * 65}\n \tSTD-IN=\"{stdin}\" \n\t{'-' * 55}\n \tSTD-OUT==> \"{stdout}\"\n\t{'-' * 55}\n\tSTD-ERROR=\"{stderr}")
    for line in stdout:
        print('... ' + line.strip('\n'))

    return client

if __name__ == "__main__":
    response = setup_ssh_client()
    print(response)