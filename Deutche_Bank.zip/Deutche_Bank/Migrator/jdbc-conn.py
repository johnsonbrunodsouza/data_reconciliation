from google.cloud import storage
import jaydebeapi
import subprocess


# Hive JDBC settings
hive_jdbc_url = 'jdbc:mariadb://ec2-3-236-147-154.compute-1.amazonaws.com:3306/hive'#'jdbc:mariadb://ip-172-31-70-212.ec2.internal:3306/hive' #'jdbc:hive2://ec2-3-236-147-154.compute-1.amazonaws.com:10000/default'# 'http://ec2-3-236-147-154.compute-1.amazonaws.com:10000/'
hive_jdbc_driver = 'org.mariadb.jdbc.Driver'
hive_jdbc_class_path = r'C:\NTTDATA\Deutche_bank\mariadb-java-client-3.1.4.jar'  # Path to the Hive JDBC driver JAR

# Hive settings
hive_db = 'hdm_test'  # Hive database name
hive_table = 'sample_table1'  # Hive table name


# Check if the table is partitioned
def query_exec(cursor):
    cursor.execute(f"""select 
	t.DatabaseName, 
	t.SchemaName,
	t.TableName,
	t.TableType,
	pk.PrimaryKey,
	foreignkey.ForeignKey,
	COALESCE (ts.TotalSize, partsize.TotalSize) as TotalSize,
	part.PartitionColumn,
	loc.Location
from (
	SELECT 
		d.NAME as DatabaseName, 
		'' as SchemaName, 
		t.TBL_NAME as TableName,
		t.TBL_TYPE as TableType,
		'' as IndexColumn,
		t.LAST_ACCESS_TIME as LastAccessed
	FROM hive.TBLS t 
	inner join hive.DBS d 
		ON t.DB_ID = d.DB_ID 
) as t
inner join (
	select 
		ccd.NAME as DatabaseName,
		cct.TBL_NAME as TableName,
		count(ccc.CD_ID) as ColumnCount
	from hive.TBLS cct
	inner join hive.DBS ccd 
		ON cct.DB_ID = ccd.DB_ID 
	JOIN hive.SDS ccs 
		ON cct.SD_ID = ccs.SD_ID 
	JOIN hive.COLUMNS_V2 ccc
		ON ccs.CD_ID = ccc.CD_ID 
	group by ccd.NAME, cct.TBL_NAME
) as cc
	on t.TableName = cc.TableName
	and t.DatabaseName = cc.DatabaseName
left join (
	select 
		d.NAME as DatabaseName,  
		t.TBL_NAME as TableName,
		tp.PARAM_VALUE as TotalSize
	FROM hive.TBLS t 
	inner join hive.DBS d 
		ON t.DB_ID = d.DB_ID 
	left join hive.TABLE_PARAMS tp 
		on t.TBL_ID = tp.TBL_ID 
		and tp.PARAM_KEY = 'totalSize'
) as ts
	on t.TableName = ts.TableName
	and t.DatabaseName = ts.DatabaseName
left join (
	select 
		d.NAME as DatabaseName,  
		t.TBL_NAME as TableName,
		tp.PARAM_VALUE as Comments
	FROM hive.TBLS t 
	inner join hive.DBS d 
		ON t.DB_ID = d.DB_ID 
	left join hive.TABLE_PARAMS tp 
		on t.TBL_ID = tp.TBL_ID 
		and tp.PARAM_KEY = 'comment'
) as com
	on t.TableName = com.TableName
	and t.DatabaseName = com.DatabaseName
left join (
	select 
		d.NAME as DatabaseName,  
		t.TBL_NAME as TableName,
		tp.PARAM_VALUE as RowCount
	FROM hive.TBLS t 
	inner join hive.DBS d 
		ON t.DB_ID = d.DB_ID 
	left join hive.TABLE_PARAMS tp 
		on t.TBL_ID = tp.TBL_ID 
		and tp.PARAM_KEY = 'numRows'
) as rowcount
	on t.TableName = rowcount.TableName
	and t.DatabaseName = rowcount.DatabaseName
left join (
	select 
		d.NAME as DatabaseName,  
		t.TBL_NAME as TableName,
		FROM_UNIXTIME(tp.PARAM_VALUE) as LastModified
	FROM hive.TBLS t 
	inner join hive.DBS d 
		ON t.DB_ID = d.DB_ID 
	left join hive.TABLE_PARAMS tp 
		on t.TBL_ID = tp.TBL_ID 
		and tp.PARAM_KEY = 'transient_lastDdlTime'
) as lm
	on t.TableName = lm.TableName
	and t.DatabaseName = lm.DatabaseName
left join (
	select 
		d.NAME as DatabaseName,  
		t.TBL_NAME as TableName, 
		GROUP_CONCAT(pk.PKEY_NAME order by pk.INTEGER_IDX) as PartitionColumn
	from hive.TBLS t 
	inner join hive.DBS d 
		ON t.DB_ID = d.DB_ID
	left join hive.PARTITION_KEYS pk 
		on t.TBL_ID = pk.TBL_ID 
	group by pk.TBL_ID 
) as part
	on t.TableName = part.TableName
	and t.DatabaseName = part.DatabaseName
left join (	
	select
		base.DatabaseName,
		base.TableName,	
		GROUP_CONCAT(parts.Location) as Location
	from (
		select 
			d.NAME as DatabaseName,
			t.TBL_NAME as TableName,
			s.LOCATION as Location,
			s.CD_ID 
		from hive.TBLS t 
		inner join hive.DBS d 
			on d.DB_ID =t.DB_ID 
		left join hive.SDS s 
				on s.SD_ID = t.SD_ID 
	) as base
	left join (
		select 
			s.LOCATION as Location,
			s.CD_ID 
		from hive.SDS s 		
	) as parts
		on base.CD_ID = parts.CD_ID
	group by base.DatabaseName,
		base.TableName
) as loc
	on t.TableName = loc.TableName
	and t.DatabaseName = loc.DatabaseName
left join (
	select
		d.NAME as DatabaseName,
		t.TBL_NAME as TableName,
		SUM(pp.PARAM_VALUE) as TotalSize
	from hive.TBLS t 
	inner join hive.DBS d 
		on d.DB_ID =t.DB_ID  
	left join hive.PARTITIONS p 
		on t.TBL_ID = p.TBL_ID 
	left join hive.PARTITION_PARAMS pp 
		on p.PART_ID = pp.PART_ID 
		and pp.PARAM_KEY = 'totalSize'
	group by d.NAME, t.TBL_NAME 
) as partsize
	on t.TableName = partsize.TableName
	and t.DatabaseName = partsize.DatabaseName
left join (
	select
		d.NAME as DatabaseName,
		t.TBL_NAME as TableName,
		SUM(pp.PARAM_VALUE) as RowCount
	from hive.TBLS t 
	inner join hive.DBS d 
		on d.DB_ID =t.DB_ID  
	left join hive.PARTITIONS p 
		on t.TBL_ID = p.TBL_ID 
	left join hive.PARTITION_PARAMS pp 
		on p.PART_ID = pp.PART_ID 
		and pp.PARAM_KEY = 'numRows'
	group by d.NAME, t.TBL_NAME 
) as partrowcount
	on t.TableName = partrowcount.TableName
	and t.DatabaseName = partrowcount.DatabaseName
left join (
	select
		d.NAME as DatabaseName,
		t.TBL_NAME as TableName,
		GROUP_CONCAT(cv.COLUMN_NAME) as PrimaryKey
	from hive.TBLS t 
	inner join hive.DBS d 
		on d.DB_ID =t.DB_ID
	inner join hive.KEY_CONSTRAINTS kc 
		on t.TBL_ID = kc.PARENT_TBL_ID 
		and kc.CONSTRAINT_TYPE = 0
	inner join hive.SDS s
	    ON t.SD_ID = s.SD_ID     
	inner join hive.COLUMNS_V2 cv
		on cv.CD_ID = s.CD_ID 
		and cv.INTEGER_IDX = kc.PARENT_INTEGER_IDX 
	group by d.NAME, t.TBL_NAME
) as pk
	on t.TableName = pk.TableName
	and t.DatabaseName = pk.DatabaseName  
left join (
	select 
		fk.DatabaseName,
		fk.TableName,
		GROUP_CONCAT(fk.ForeignKey SEPARATOR '#') as ForeignKey
	from (
		select
			d.NAME as DatabaseName,
			t.TBL_NAME as TableName,	
			CONCAT_WS('-', kc.CONSTRAINT_NAME, GROUP_CONCAT(distinct cv.COLUMN_NAME)) as ForeignKey
		from hive.TBLS t 
		inner join hive.DBS d 
			on d.DB_ID =t.DB_ID
		inner join hive.KEY_CONSTRAINTS kc 
			on t.TBL_ID = kc.CHILD_TBL_ID 
			and kc.CONSTRAINT_TYPE = 1
		inner join hive.SDS s
		    ON t.SD_ID = s.SD_ID     
		inner join hive.COLUMNS_V2 cv
			on cv.CD_ID = s.CD_ID 
			and cv.INTEGER_IDX = kc.CHILD_INTEGER_IDX 
		group by d.NAME, t.TBL_NAME, kc.CONSTRAINT_NAME 
	) fk
	group by fk.DatabaseName,	fk.TableName
) as foreignkey
	on t.TableName = foreignkey.TableName
	and t.DatabaseName = foreignkey.DatabaseName
	where t.TableName = 'books';""")
    results = cursor.fetchall()
    return results


def copy_hive_files_to_gcs(hdfs_source_path, gcs_destination_path):
    # HDFS path of the Hive table data
    #hdfs_source_path = f"/user/hive/warehouse/{hive_database}.db/{hive_table}"
    # GCS destination path
    #gcs_destination_path = f"gs://{gcs_bucket_path}/"

    # DistCp command to copy data from HDFS to GCS
    distcp_command = f"hadoop distcp {hdfs_source_path} {gcs_destination_path}"

    try:
        # Execute the DistCp command
        subprocess.run(distcp_command, shell=True, check=True)
        print("Hive files copied to GCS successfully!")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred while copying Hive files to GCS: {e}")


def main():

    #conn_props = { 'user' : 'hive', 'password' : 'ykwyyJNs6Y2pgiZm'}
    credentials_path='C:/Users/316716/Downloads/bigquery-eval-hd1341-f4215fb67922.json'
    #credentials_path='home/hadoop/bigquery-eval-hd1341-f4215fb67922.json'
    gcs_client = storage.Client.from_service_account_json(credentials_path)
    project_id = 'bigquery-eval-hd1341'
    gcs_bucket = 'tpcds-benchmarking-data'


    try:
        # Establish JDBC connection to Hive
        conn = jaydebeapi.connect(
            jclassname=hive_jdbc_driver,
            url=hive_jdbc_url,
            jars=hive_jdbc_class_path,
            driver_args={            
                "user": "hive",
                "password": "ykwyyJNs6Y2pgiZm"
                }
        )
        cursor = conn.cursor()

        # Check if the table is partitioned
        query_results = query_exec(cursor)
        print(query_results)
        
        for row in query_results:
            db_name = row[0]
            table_name = row[2]
            part_column = row[7]
            #hdfs_source_path = query_results[-1][-1]
            hdfs_source_path = query_results[-1][-1].split(':8020')[1]
            print(db_name, table_name, part_column)
            
            if part_column is None:
                is_partitioned = False
            is_partitioned = True
            
            #is_partitioned = check_partitioned(cursor)
            print(f"Table {table_name} is {'partitioned' if is_partitioned else 'non-partitioned'}.")


            gcs_destination_path = f'gs://{gcs_bucket}/{table_name}/'

            print("HDFS source path is", hdfs_source_path)

            copy_hive_files_to_gcs(hdfs_source_path, gcs_destination_path)

    except Exception as e:
        print(f"An error occurred: {str(e)}")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    main()
