#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import streamlit as st
import ast
import _ast
import os
import glob
import platform
import yaml
import datetime 
import shutil
import subprocess
import logging.config
import warnings
import sys
#sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
sys.path[0] = r'C:\NTTDATA\Deutche_bank\hashmap_data_cataloger'
from argparse import ArgumentParser, ArgumentTypeError
from providah.factories.package_factory import PackageFactory as providah_pkg_factory
from hdc.core.asset_mapper import AssetMapper
from hdc.core.cataloger import Cataloger
from hdc.core.exceptions.hdc_error import HdcError
from hdc.utils import file_utils
import altair as alt
import json 
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from PIL import Image

# ### added in homemachine
# from hdc.core.dao.hive import Hive
# from hdc.core.dao.jdbc_connector import JdbcConnector
# import jaydebeapi

#from hdc.vault.aws_secrets_manager import AWSSecretsManager


st.set_page_config(layout="wide", page_title="NTT Data Cataloguer")
conn_params = json.load(open(os.path.join(os.path.split(os.path.abspath(__file__))[0], "widgets.json")))

def create_widgets(connection_key):
    connection_profile = {}
    uploaded_file = None
    for widget in conn_params[connection_key]['params']:
        if widget['widget_type'] == "text_input":
            if 'driver' not in widget['param_name']:
                connection_profile[widget['param_name']] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['widget_name']}"))
            else:
                if 'driver' not in connection_profile:
                    connection_profile['driver'] = {}
                connection_profile['driver'][widget['param_name'].replace('driver','')] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['widget_name']}"))
        elif widget['widget_type'] == "password":
            connection_profile[widget['param_name']] = str(st.text_input(label=widget['widget_name'], value=widget['default'], disabled=eval(widget['disabled']), key=f"{connection_key}_{widget['widget_name']}", type="password"))
        elif widget['widget_type'] == "selectbox":
            if 'driver' not in widget['param_name']:
                connection_profile[widget['param_name']] = str(st.selectbox(label=widget['widget_name'], options=widget['options'], disabled=eval(widget['disabled']), index=widget['default'], key=f"{connection_key}_{widget['widget_name']}"))
            else:
                if 'driver' not in connection_profile:
                    connection_profile['driver'] = {}
                    connection_profile['driver'][widget['param_name'].replace('driver','')] = str(st.selectbox(label=widget['widget_name'], options=widget['options'], disabled=eval(widget['disabled']), index=widget['default'], key=f"{connection_key}_{widget['widget_name']}"))
        elif widget['widget_type'] == "text":
            connection_profile[widget['param_name']] = str(st.text(body=widget['widget_name']))
        elif widget['widget_type'] == "file_uploader":
            uploaded_file = st.file_uploader(label=widget['widget_name'], key=f"{connection_key}_{widget['widget_name']}", accept_multiple_files=False)
        if uploaded_file is not None:
            current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
            with open(f"{uploaded_file.name}_{current_timestamp}", "wb") as f:
                f.write(uploaded_file.getbuffer())
                connection_profile[widget['param_name']] = os.path.join(os. getcwd(), f"{uploaded_file.name}_{current_timestamp}")
    return connection_profile

def inspect_module(module_path, replace_text):
    returnlist = []
    for file in glob.glob(os.path.join(module_path,"[a-z]*.py")):
        with open(file) as mf:
            tree = ast.parse(mf.read())
        module_classes = [c.name.replace(replace_text,'') for c in [_ for _ in tree.body if isinstance(_, _ast.ClassDef)]]  
        returnlist.append(module_classes[0])
    
    if '' in returnlist:
        returnlist.pop(returnlist.index(''))
    if 'Rdbms' in returnlist:
        returnlist.pop(returnlist.index('Rdbms'))    
    return returnlist

def user_home_directory():
    userhome = ""
    if platform.system().lower() != 'windows':
        userhome = os.getenv('HOME')
    else:
        userhome = os.getenv('USERPROFILE')
    return userhome

def check_for_empty_params(config):
    missingconfigs = []
    for key in config.keys():
        if config[key] == "" and key not in  ['database', 'dataset']:
            missingconfigs.append(f"Missing config for {key}.")
    return missingconfigs

def start_here(app_configuration, source, destination, log_settings, run):
    try:
        app_config: dict = file_utils.get_app_config(app_configuration)
        
        if log_settings is not None:
            logging.config.dictConfig(file_utils.yaml_parser(yaml_file_path=log_settings))
        else:
            logging.config.dictConfig(file_utils.yaml_parser(yaml_file_path=file_utils.get_default_log_config_path()))

        if app_config is not None:
            if run.lower() == 'map':
                try:
                    asset_mapper: AssetMapper = providah_pkg_factory.create(key='AssetMapper',
                                                                            library='hdc',
                                                                            configuration={
                                                                                'source': source,
                                                                                'destination': destination,
                                                                                'app_config': app_configuration
                                                                            })

                    if asset_mapper.map_assets():
                        print(
                            f"Successfully mapped the source '{source}' to destination '{destination}'")
                    return f"Successfully mapped the source '{source}' to destination '{destination}'"

                except HdcError as hde:
                    #print(hde)
                    raise HdcError(message=hde)

            elif run.lower() == 'catalog':
                try:
                    cataloger: Cataloger = providah_pkg_factory.create(key='Cataloger',
                                                                       library='hdc',
                                                                       configuration={
                                                                           'source': source,
                                                                           'app_config': app_configuration})
                    #df_catalog = cataloger.obtain_catalog()
                    catalog_list = cataloger.obtain_catalog()


                    if downloaddata:
                        output_file = cataloger.pretty_print(catalog_list)
                        # output_file = cataloger.pretty_print(catalog_list[0])
                        # output_file = cataloger.pretty_print(catalog_list[1])
                        st.info(f"Downloaded data at {os.path.join(os.path.split(os.path.split(os.path.split(os.path.abspath(__file__))[0])[0])[0], output_file)}")
                    
                    #return df_catalog
                    return catalog_list
                except HdcError as hde:
                     #print(hde)
                    raise HdcError(message=hde)
        else:
            raise HdcError(message=f"Could not find file {app_config}")

    except ArgumentTypeError as err:
        # hdc_parser.print_usage()
        raise HdcError(message=err)

    except RuntimeError as err:
        raise HdcError(message=err)

def generateresultsfordatatab(returnstatus):
    with dataanalyzer:
        with st.expander("Table Summary", expanded=True):
            st.dataframe(data=returnstatus[1], use_container_width=True)
        with st.expander("Table Details", expanded=True):
            st.dataframe(data=returnstatus[0], use_container_width=True)

def generateresultsforanalysistab(returnstatus):
    with analysis:                
        with st.expander("Table Summary", expanded=True):
            col1, col2 = st.columns(spec=2, gap="large")
            with col1:
                create_bar_chart(returnstatus[1], x="DatabaseName", color="SchemaName", title="Count of tables by DB & Schemas", datefilters=False, color_map={})
                create_bar_chart(returnstatus[1], x="RowCountGrouping", color="RowCountGrouping", title="Distribution by Row Counts", datefilters=False, color_map=color_map)
                create_bar_chart(returnstatus[1], x="LastModified", color="", title="Count of tables by last DDL", datefilters=True, color_map={})
            with col2:
                create_bar_chart(returnstatus[1], x="TableSizeGrouping", color="TableSizeGrouping", title="Distribution by Table Size", datefilters=False, color_map=color_map)
                create_bar_chart(returnstatus[1], x="ColCountGrouping", color="ColCountGrouping", title="Distribution by Column Counts", datefilters=False, color_map=color_map)
                create_bar_chart(returnstatus[1], x="LastAccessed", color="", title="Count of tables by Last Accessed", datefilters=True, color_map={})
                convert_to = {'RowCount':int, 'ColumnCount':int,'TableSizeInMb':int}
                returnstatus[1] = returnstatus[1].astype(convert_to)
                create_bubble_chart(returnstatus[1], x="RowCount", y="ColumnCount", color="DatabaseName", size='TableSizeInMb', hover_data=['TableName'], title="Distribution based on Row count, Column Count & Size")
            col5, col6, col7 = st.columns(3)
            with col5:
                create_plotly_metric(label="Triggers", value=returnstatus[1].loc[(returnstatus[1].TriggerPresent == "Y")].shape[0], prefix="", suffix="", valueformat="")
            with col6:
                create_plotly_metric(label="Partitions", value=returnstatus[1].loc[(returnstatus[1].PartitionColumn != "")].shape[0], prefix="", suffix="", valueformat="")
            if 'IndexColumns' in returnstatus[1]:
                with col7:
                    create_plotly_metric(label="Indexes", value=returnstatus[1].loc[(returnstatus[1].IndexColumns != "")].shape[0], prefix="", suffix="", valueformat="")                        

        
        with st.expander("Table Details", expanded=True):
            col3, col4 = st.columns(spec=2,gap="large")
            with col3:
                create_bar_chart(returnstatus[0], x="COLUMN_TYPE", color="COLUMN_TYPE", title="Count of columns by DataType", datefilters=False, color_map={})
                create_bar_chart(returnstatus[0], x="CHARACTER_SET_NAME", color="CHARACTER_SET_NAME", title="Count of columns by Character Set", datefilters=False, color_map={})
            with col4:
                #create_bar_chart(returnstatus[1].query('PrimaryKey == "" & ProbableWatermarkColumns == ""'), x="DatabaseName", color="DatabaseName", title="Count of tables without PK and watermarks", datefilters=False, color_map={})
                create_bar_chart(returnstatus[0], x="COLLATION_NAME", color="COLLATION_NAME", title="Count of columns by Collation", datefilters=False, color_map={})

def create_plotly_metric(label, value, prefix, suffix, valueformat):    
    fig = go.Figure()
    fig.add_trace(go.Indicator(mode = "number", value = value, title= {"text": f"<span style='font-size:2em;color:gray'>{label}</span>"}, number={"valueformat": valueformat, "prefix": prefix, "suffix": suffix, "font": {"size": 40}}))
    st.plotly_chart(fig, theme="streamlit", use_container_width=True)

def determine_size_grouping(size):
    if int(size) < sizesmallhigh:
        return pd.Series(["Small", f"{str(sizesmalllow)} < Small < {str(sizesmallhigh)}"])
    elif int(size) < sizemedhigh:
        return pd.Series(["Medium", f"{str(sizemedlow)} < Medium < {str(sizemedhigh)}"])
    else:
        return pd.Series(["Large", f"{str(sizelargelow)} < Large"])

def determine_rowcount_grouping(rowcount):
    if int(rowcount) < rowcountsmallhigh:
        return "Small"
    elif int(rowcount) < rowcountmedhigh:
        return "Medium"
    else:
        return "Large"

def determine_colcount_grouping(colcount):
    if int(colcount) < colcountsmallhigh:
        return "Small"
    elif int(colcount) < colcountmedhigh:
        return "Medium"
    else:
        return "Large"

def create_bubble_chart(df, x, y,  color, size, hover_data, title):
    fig = px.scatter(df, x=x, y=y, color=color, size=size, hover_data=hover_data, title="<b>" + title + "</b>", log_x=True)
    st.plotly_chart(fig, theme=None, use_container_width=True)

def create_bar_chart(df, x, color, title, datefilters, color_map):
    if color:
        fig = px.histogram(df, x=x, color=color, title="<b>" + title + "</b>", text_auto='.2s', color_discrete_map=color_map, hover_data=df.columns)
    else:
        fig = px.histogram(df, x=x, title="<b>" + title + "</b>", text_auto='.2s', hover_data=df.columns)  
    fig.update_traces(textfont_size=12, textangle=0, textposition="outside", cliponaxis=False)

    if datefilters:
        fig.update_layout(
                            xaxis=dict(
                                rangeselector=dict(
                                    buttons=list([
                                        dict(count=1,
                                            label="1m",
                                            step="month",
                                            stepmode="backward"),
                                        dict(count=3,
                                            label="3m",
                                            step="month",
                                            stepmode="backward"),
                                        dict(count=6,
                                            label="6m",
                                            step="month",
                                            stepmode="backward"),
                                        dict(count=1,
                                            label="YTD",
                                            step="year",
                                            stepmode="todate"),
                                        dict(count=1,
                                            label="1y",
                                            step="year",
                                            stepmode="backward"),
                                        dict(count=2,
                                            label="2y",
                                            step="year",
                                            stepmode="backward"),
                                        dict(count=5,
                                            label="5y",
                                            step="year",
                                            stepmode="backward"),
                                        dict(count=10,
                                            label="10y",
                                            step="year",
                                            stepmode="backward"),
                                        dict(step="all")
                                    ])
                                ),
                                rangeslider=dict(
                                    visible=True
                                ),
                                type="date"
                            ),
                            bargap=0.2
                        )
    st.plotly_chart(fig, theme=None,  use_container_width=True)


def generateresults(returnstatus):
    if type(returnstatus) == list:
        returnstatus[0].fillna('', inplace=True)
        returnstatus[1].fillna('', inplace=True)
        returnstatus[1][['TableSizeGrouping', 'TableSizeGroupingDesc']] = returnstatus[1]['TableSizeInMb'].apply(determine_size_grouping)
        returnstatus[1]['RowCountGrouping'] = returnstatus[1]['RowCount'].apply(determine_rowcount_grouping)
        returnstatus[1]['ColCountGrouping'] = returnstatus[1]['ColumnCount'].apply(determine_colcount_grouping)
        generateresultsfordatatab(returnstatus)
        generateresultsforanalysistab(returnstatus)  
        st.info("Generated Insights. Please refer to the Analysis/Data tabs...")
    else:
        print('Could not generate Insights.')


def initiate_cataloger(run_mode, source, target, recreate, source_connection, target_connection, placeholder):
    createconfig = True
    with placeholder.container():
        try:
            st.info("Validating inputs.")

            if source != "":
                for missing_config in check_for_empty_params(source_connection):        
                    st.error(missing_config)
                    createconfig = False
            # if target != "":
            #     if 'secret_name' in target_connection:
            #         target_connection = get_credentials(target_connection)
            if target != "":
                for missing_config in check_for_empty_params(target_connection):        
                    st.error(missing_config)
                    createconfig = False

            if createconfig:
                st.info("Creating Configurations...")
                create_manifest(source, target, recreate)
                print(target_connection)
                create_profile(source, target, source_connection, target_connection)
                st.info("Configurations created...")
                st.info("Initiating Process...")                
                
                app_config = os.path.join(user_home_directory(), ".hdc", "hdc.yml")                
                returnstatus = start_here(app_config, source.lower(), target.lower(), os.path.join(os.path.split(os.path.split(os.path.split(os.path.abspath(__file__))[0])[0])[0], "resources", "log_settings.yml"), run_mode)                
                generateresults(returnstatus)
        except HdcError as hde:
            # st.exception(f"{hde.message} - {hde.additional_args['traceback']}")
            st.exception(f"{hde.message}")
        except Exception as e:
            st.exception(str(e))

def create_profile(source, target, source_connection, target_connection):
    profile = {}
    hdc_dir = os.path.join(user_home_directory(), ".hdc")
    hdc_archive = os.path.join(user_home_directory(), ".hdc", "Archive")
    if not os.path.isdir(hdc_dir):
        os.makedirs(hdc_dir) 
    if not os.path.isdir(hdc_archive):
        os.makedirs(hdc_archive)

    profile[source.lower()] = source_connection
    if target != "":
        profile[target.lower()] = target_connection
    
    current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
    if os.path.exists(os.path.join(hdc_dir, 'profile.yml')):
        shutil.move(os.path.join(hdc_dir, 'profile.yml'), os.path.join(hdc_archive, f"profile_{current_timestamp}.yml"))
    
    with open(os.path.join(hdc_dir, 'profile.yml'), 'w') as outfile:
        yaml.dump(profile, outfile, default_flow_style=False)
    

def create_manifest(source, target, recreate):
    manifest = {}
    hdc_dir = os.path.join(user_home_directory(), ".hdc")
    hdc_archive = os.path.join(user_home_directory(), ".hdc", "Archive")
    if not os.path.isdir(hdc_dir):
        os.makedirs(hdc_dir) 
    if not os.path.isdir(hdc_archive):
        os.makedirs(hdc_archive) 


    manifest['sources'] = {}
    manifest['sources'][source.lower()] = {}
    manifest['sources'][source.lower()]['type'] = f"{source}Crawler"
    manifest['sources'][source.lower()]['conf'] = {}
    manifest['sources'][source.lower()]['conf']['type'] = source if source != "BigQuery" else f"{source}DAO"
    manifest['sources'][source.lower()]['conf']['profile'] = source.lower()
    
    if target != "":
        manifest['destinations'] = {}
        manifest['destinations'][target.lower()] = {}
        manifest['destinations'][target.lower()]['type'] = f"{target}Creator"
        manifest['destinations'][target.lower()]['conf'] = {}
        manifest['destinations'][target.lower()]['conf']['type'] = f"{target}DAO"
        manifest['destinations'][target.lower()]['conf']['profile'] = target.lower()

        manifest['mappers'] = {}
        manifest['mappers'][source.lower()] = {}
        manifest['mappers'][source.lower()][target.lower()] = {}
        manifest['mappers'][source.lower()][target.lower()]['type'] = f"{source}To{target}"
        manifest['mappers'][source.lower()][target.lower()]['conf'] = {}
        manifest['mappers'][source.lower()][target.lower()]['conf']['report'] = False
        manifest['mappers'][source.lower()][target.lower()]['conf']['recreate'] = recreate

    current_timestamp = str(datetime.datetime.now()).replace(' ','').replace('-','').replace(':','').replace('.','')
    if os.path.exists(os.path.join(hdc_dir, 'hdc.yml')):
        shutil.move(os.path.join(hdc_dir, 'hdc.yml'), os.path.join(hdc_archive, f"hdc_{current_timestamp}.yml"))
    
    with open(os.path.join(hdc_dir, 'hdc.yml'), 'w') as outfile:
        yaml.dump(manifest, outfile, default_flow_style=False)

# def get_credentials(connection):
#     #sm_reponse = AWSSecretsManager(secretname=connection['secret_name'])
#     #sm_secret = sm_reponse.get_secret()
#     connection['user'] = 'hdm'
#     connection['password'] = 'oracle1'
#     return connection

image = Image.open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'NTT_Data_Logo_Edited.png'))
st.image(image)
st.title("Data Cataloguer")

option = st.sidebar.selectbox("Cataloguer Options", ["Analyzer", "Schema Migrator"], index=0)
color_map = {'Small':'green','Medium':'yellow','Large':'orange'}

if option == "Analyzer":
    connectionanalyzer, analysis, dataanalyzer  = st.tabs(["🔗 Connections", "📈 Analysis", "🗃 Data"])
    with connectionanalyzer:
        with st.expander("Source", expanded=True):
            source = st.selectbox("Source System", inspect_module(os.path.join(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0], 'core','catalog'), 'Crawler'), key="AnalyzerSourceSystem")
            source_connection = create_widgets(source)
            downloaddata = st.checkbox(label="Download Data",key="DownloadData")            
            # if downloaddata:
            #     createselectdirectorywidget()
            st.subheader("Size Groupings")
            colsize, colrows, colcolumns = st.columns(spec=3, gap="large")

            with colsize:
                st.caption("Table Size Grouping(in Mb)")
                sizesmalllow, sizesmallhigh  = st.select_slider('Small',  options=range(0, 100500, 500), value=(0,50000), key="TableSizeSmall")
                sizemedlow, sizemedhigh  = st.select_slider('Medium',  options=range(sizesmallhigh, 300500, 500), value=(sizesmallhigh, 200000), key="TableSizeMed")
                sizelargelow, sizelargehigh  = st.select_slider('Large',  options=range(sizemedhigh, 5000500, 500), value=(sizemedhigh, 5000000), key="TableSizeLarge")

            with colrows:
                st.caption("Row Counts Grouping")
                rowcountsmalllow, rowcountsmallhigh  = st.select_slider('Small',  options=range(0, 5050000, 50000), value=(0,500000))
                rowcountmedlow, rowcountmedhigh  = st.select_slider('Medium',  options=range(rowcountsmallhigh, 10050000, 50000), value=(rowcountsmallhigh, 6000000))
                rowcountlargelow, rowcountlargehigh  = st.select_slider('Large',  options=range(rowcountmedhigh, 20050000, 50000), value=(rowcountmedhigh, 20000000))

            with colcolumns:
                st.caption("Column Counts Grouping")
                colcountsmalllow,colcountsmallhigh  = st.select_slider('Small',  options=range(0, 110, 10), value=(0,50))
                colcountmedlow,colcountmedhigh  = st.select_slider('Medium',  options=range(colcountsmallhigh, 210, 10), value=(colcountsmallhigh, 150))
                colcountlargelow, colcountlargehigh  = st.select_slider('Large',  options=range(colcountmedhigh, 1510, 10), value=(colcountmedhigh, 1500))

        if st.button("Get Insights"):
            with st.spinner("Generating Insights"):
                placeholder = st.empty()
                initiate_cataloger('catalog', source, target="", recreate="", source_connection=source_connection, target_connection="", placeholder=placeholder)        
else:
    with st.expander("Source", expanded=True):
        source = st.selectbox("Source System", inspect_module(os.path.join(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0],'core', 'catalog'), 'Crawler'), key="MigratorSourceSystem")
        source_connection = create_widgets(source)

    with st.expander("Target"):
        target = st.selectbox("Target System", inspect_module(os.path.join(os.path.split(os.path.dirname(os.path.abspath(__file__)))[0], 'core', 'create'), 'Creator'), index=1, key="MigratorTargetSystem")
        target_connection = create_widgets(target)
        recreate = st.checkbox(label="Re-Create structures",key=f"RecreateStructures")

    if st.button("Migrate"):
        with st.spinner("Migrating Schemas"):
            placeholder = st.empty()
            initiate_cataloger('map', source, target=target, recreate=recreate, source_connection=source_connection, target_connection=target_connection, placeholder=placeholder)



