#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
"""
#TODO: Module description
"""

from string import Template

import pandas as pd
from providah.factories.package_factory import PackageFactory as providah_pkg_factory

from hdc.core.catalog.rdbms_crawler import RdbmsCrawler
from hdc.core.dao.rdbms_dao import RdbmsDAO


class OracleCrawler(RdbmsCrawler):
    __template_get_all_databases = Template("""
                                                select 
                                                    NAME
                                                from v$database
                                                WHERE NAME = COALESCE(NULLIF('$db',''), NAME)
    """)

    __template_get_all_users = Template("""SELECT USERNAME as NAME FROM ALL_USERS WHERE USERNAME = COALESCE(NULLIF(CAST(UPPER('$user') AS varchar2(100)),''), USERNAME)""")

    __template_select_summary = Template("""
                                            WITH summary AS (
                                                SELECT 
                                                    OWNER  AS  SchemaName,
                                                    TABLE_NAME AS  TableName,
                                                    NUM_ROWS AS RowCounts,
                                                    TABLE_TYPE  AS TableType
                                                FROM ALL_ALL_TABLES
                                                WHERE OWNER = '$user'
                                                AND STATUS = 'VALID'
                                            ),
                                            primarykey AS (
                                                SELECT
                                                    cons.OWNER AS SchemaName,
                                                    cols.TABLE_NAME AS TableName,
                                                    LISTAGG(cols.COLUMN_NAME, ', ') WITHIN GROUP (ORDER BY cols.position) AS PrimaryKey
                                                FROM all_constraints cons, all_cons_columns cols
                                                WHERE cons.constraint_type = 'P'
                                                AND cons.constraint_name = cols.constraint_name
                                                AND cons.owner = cols.owner
                                                AND cons.OWNER = '$user'
                                                GROUP BY cons.OWNER, cols.TABLE_NAME, cols.CONSTRAINT_NAME
                                            ),
                                            foreignkeys AS (
                                                SELECT
                                                    SchemaName,
                                                    TableName,
                                                    LISTAGG(ForeignKey, ' # ') AS ForeignKey 
                                                FROM (
                                                        SELECT
                                                            cons.OWNER AS SchemaName,
                                                            cols.TABLE_NAME AS TableName,
                                                            cols.CONSTRAINT_NAME || ' - ' ||  LISTAGG(cols.COLUMN_NAME, ', ') WITHIN GROUP (ORDER BY cols.position) AS ForeignKey 
                                                        FROM all_constraints cons, all_cons_columns cols
                                                        WHERE cons.constraint_type = 'R'
                                                        AND cons.constraint_name = cols.constraint_name
                                                        AND cons.owner = cols.owner
                                                        AND cons.OWNER = '$user'
                                                        GROUP BY cons.OWNER, cols.TABLE_NAME, cols.CONSTRAINT_NAME
                                                )
                                                GROUP BY SchemaName, TableName 	
                                            ),
                                            indexes AS (
                                                SELECT
                                                    SchemaName,
                                                    TableName,
                                                    LISTAGG(Indexes, ' # ') AS Indexes 
                                                FROM (
                                                        SELECT
                                                            i.OWNER AS SchemaName,
                                                            i.TABLE_NAME AS TableName,
                                                            i.INDEX_NAME || ' - ' || LISTAGG(c.COLUMN_NAME, ', ') WITHIN GROUP (ORDER BY c.COLUMN_POSITION) AS Indexes
                                                        FROM ALL_INDEXES i
                                                        LEFT JOIN ALL_IND_COLUMNS c
                                                            ON i.OWNER = c.INDEX_OWNER 
                                                            AND i.TABLE_NAME = c.TABLE_NAME 
                                                            AND i.INDEX_NAME = c.INDEX_NAME 
                                                        WHERE i.OWNER = '$user'
                                                        GROUP BY i.OWNER, i.TABLE_NAME, i.INDEX_NAME
                                                )
                                                GROUP BY SchemaName, TableName 		
                                            ),
                                            columncounts AS (
                                                SELECT 
                                                    OWNER AS SchemaName,
                                                    TABLE_NAME AS TableName,
                                                    count(*) AS ColumnCount
                                                FROM ALL_TAB_COLUMNS
                                                WHERE OWNER = '$user'
                                                GROUP BY OWNER, TABLE_NAME 
                                            ),
                                            sizes AS (
                                                select 
                                                    OWNER AS SchemaName,
                                                    segment_name AS TableName,
                                                    sum(bytes)/1024/1024 AS TableSizeInMb
                                                from dba_segments 
                                                where segment_type='TABLE' 
                                                and OWNER = '$user' 
                                                group by OWNER, segment_name
                                            ),
                                            comments AS (
                                                SELECT 
                                                    OWNER AS SchemaName,
                                                    TABLE_NAME AS TableName,
                                                    COMMENTS AS Comments
                                                FROM ALL_TAB_COMMENTS 
                                                WHERE OWNER = '$user'
                                                AND TABLE_TYPE = 'TABLE'
                                            ),
                                            probablewatermarks AS (
                                                SELECT 
                                                    OWNER AS SchemaName,
                                                    TABLE_NAME AS TableName,
                                                    LISTAGG(COLUMN_NAME, ', ') AS ProbableWatermarkColumns
                                                FROM ALL_TAB_COLUMNS
                                                WHERE OWNER = '$user'
                                                AND DATA_TYPE IN ('DATE', 'TIMESTAMP', 'TIMESTAMP WITH TIME ZONE', 'TIMESTAMP WITH LOCAL TIME ZONE')
                                                GROUP BY OWNER, TABLE_NAME
                                            ),
                                            triggers AS (
                                                SELECT 
                                                    OWNER AS SchemaName,
                                                    TABLE_NAME AS TableName,
                                                    'Y' AS TriggerPresent
                                                FROM ALL_TRIGGERS 
                                                WHERE OWNER = '$user'
                                            ),
                                            partitions AS (
                                                SELECT 
                                                    OWNER AS SchemaName,
                                                    NAME AS TableName,
                                                    LISTAGG(COLUMN_NAME, ', ') WITHIN GROUP (ORDER BY COLUMN_POSITION) AS PartitionColumn
                                                FROM ALL_PART_KEY_COLUMNS
                                                WHERE OWNER = '$user'
                                                GROUP BY OWNER, NAME 
                                            ),
                                            lastmodified AS (
                                                SELECT 
                                                    OWNER AS SchemaName,
                                                    OBJECT_NAME AS TableName,
                                                    LAST_DDL_TIME AS LastModified
                                                FROM ALL_OBJECTS 
                                                WHERE OBJECT_TYPE = 'TABLE'
                                                AND OWNER = '$user'
                                            )
                                            SELECT 
                                                '$db' AS DatabaseName,
                                                summ.SchemaName,
                                                summ.TableName,
                                                summ.TableType,
                                                p.PrimaryKey,
                                                f.ForeignKey,
                                                i.Indexes,
                                                summ.RowCounts,
                                                c.ColumnCount,
                                                s.TableSizeInMb,
                                                co.Comments,
                                                pw.ProbableWatermarkColumns,
                                                COALESCE(t.TriggerPresent, 'N') AS TriggerPresent,
                                                pa.PartitionColumn,
                                                '' AS LastAccessed,
                                                lm.LastModified 
                                            FROM summary summ
                                            LEFT JOIN primarykey p
                                                ON p.SchemaName = summ.SchemaName 
                                                AND p.TableName  = summ.TableName 
                                            LEFT JOIN foreignkeys f
                                                ON f.SchemaName = summ.SchemaName 
                                                AND f.TableName  = summ.TableName
                                            LEFT JOIN indexes i
                                                ON i.SchemaName = summ.SchemaName 
                                                AND i.TableName  = summ.TableName
                                            LEFT JOIN columncounts c
                                                ON c.SchemaName = summ.SchemaName 
                                                AND c.TableName  = summ.TableName
                                            LEFT JOIN sizes s
                                                ON s.SchemaName = summ.SchemaName 
                                                AND s.TableName  = summ.TableName
                                            LEFT JOIN comments co
                                                ON co.SchemaName = summ.SchemaName 
                                                AND co.TableName  = summ.TableName
                                            LEFT JOIN probablewatermarks pw
                                                ON pw.SchemaName = summ.SchemaName 
                                                AND pw.TableName  = summ.TableName
                                            LEFT JOIN triggers t
                                                ON t.SchemaName = summ.SchemaName 
                                                AND t.TableName  = summ.TableName
                                            LEFT JOIN partitions pa
                                                ON pa.SchemaName = summ.SchemaName 
                                                AND pa.TableName  = summ.TableName
                                            LEFT JOIN lastmodified lm
                                                ON lm.SchemaName = summ.SchemaName 
                                                AND lm.TableName  = summ.TableName
    """)
    # __template_select_all_tables = Template("SELECT '$db' as DATABASE_NAME, "
    #                                         "'$user' as SCHEMA_NAME, "
    #                                         "ALL_TAB_COLUMNS.TABLE_NAME as TABLE_NAME, "
    #                                         "ALL_TAB_COLUMNS.COLUMN_NAME AS COLUMN_NAME, "
    #                                         "ALL_TAB_COLUMNS.DATA_TYPE AS COLUMN_TYPE, "
    #                                         "CASE "
    #                                         "WHEN data_precision IS NOT NULL AND NVL (data_scale, 0) > 0 "
    #                                         "THEN '(' || data_precision || ',' || data_scale || ')' "
    #                                         " WHEN data_precision IS NOT NULL AND NVL (data_scale, 0) = 0"
    #                                         "THEN '(' || data_precision || ')'"
    #                                         "END AS COLUMN_SIZE, "
    #                                         "ALL_TAB_COLUMNS.NULLABLE AS NOT_NULL "
    #                                         "FROM ALL_TAB_COLUMNS JOIN USER_TABLES "
    #                                         "ON (ALL_TAB_COLUMNS.TABLE_NAME = USER_TABLES.TABLE_NAME "
    #                                         "AND USER_TABLES.STATUS = 'VALID') ")

    __template_select_all_tables = Template("""
                                                SELECT  
                                                    '$db' AS DATABASE_NAME,
                                                    T.OWNER AS SCHEMA_NAME,
                                                    T.TABLE_NAME,
                                                    T.COLUMN_NAME,
                                                    CASE 
                                                        WHEN T.DATA_TYPE LIKE 'INTERVAL%' OR T.DATA_TYPE LIKE 'TIMESTAMP%' THEN REGEXP_REPLACE(T.DATA_TYPE ,'\(.\)','')
                                                        ELSE T.DATA_TYPE
                                                    END AS COLUMN_TYPE,
                                                    CASE 
                                                        WHEN T.DATA_TYPE IN ('VARCHAR2','NVARCHAR2','CHAR','NCHAR','CLOB','NCLOB','RAW','ROWID','UROWID','LONG RAW','BLOB') THEN '(' || TO_CHAR(DATA_LENGTH) || ')'
                                                        WHEN T.DATA_TYPE = 'NUMBER' AND DATA_PRECISION IS NOT NULL THEN '(' || TO_CHAR(DATA_PRECISION) || ',' || TO_CHAR(DATA_SCALE) || ')'
                                                        WHEN T.DATA_TYPE = 'NUMBER' AND DATA_PRECISION IS NULL AND DATA_SCALE IS NOT NULL THEN '(38,' || TO_CHAR(DATA_SCALE) || ')'
                                                        WHEN T.DATA_TYPE = 'NUMBER' AND DATA_PRECISION IS NULL AND DATA_SCALE IS NULL THEN '(38,18)'
                                                        WHEN T.DATA_TYPE = 'FLOAT' THEN ''
                                                        WHEN T.DATA_TYPE LIKE 'TIMESTAMP%' THEN '(' || TO_CHAR(DATA_SCALE) || ')'
                                                        WHEN T.DATA_TYPE LIKE 'INTERVAL%' THEN '(100)'
                                                        ELSE ''
                                                    END AS COLUMN_SIZE,
                                                    CASE 
                                                        WHEN T.NULLABLE = 'Y' THEN 'N' 
                                                        ELSE 'Y'
                                                    END AS NOT_NULL,
                                                    T.DATA_DEFAULT AS DEFAULT_VALUE,
                                                    C.COMMENTS AS COMMENT_STRING,
                                                    T.CHARACTER_SET_NAME AS CHARACTER_SET_NAME,
                                                    T.COLLATION AS COLLATION_NAME
                                                FROM ALL_TAB_COLUMNS T
                                                INNER JOIN ALL_ALL_TABLES AAT
                                                    ON AAT.OWNER = T.OWNER 
                                                    AND AAT.TABLE_NAME = T.TABLE_NAME 
                                                    AND AAT.STATUS = 'VALID'	
                                                LEFT JOIN ALL_COL_COMMENTS C 
                                                    ON T.TABLE_NAME = C.TABLE_NAME 
                                                    AND T.OWNER = C.OWNER 
                                                    AND T.COLUMN_NAME = C.COLUMN_NAME  
                                                WHERE T.OWNER = '$user'
                                                ORDER BY T.OWNER, T.TABLE_NAME, T.COLUMN_ID
    """)
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def obtain_catalog(self) -> pd.DataFrame:
        try:
            df_table_catalog = pd.DataFrame()
            df_table_summary = pd.DataFrame()
            dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})

            # Extract the table metadata/catalog from connected Teradata source
            oracle_database = dao.get_conn_profile_key("database") if dao.get_conn_profile_key("database") is not None \
                else dao.get_conn_profile_key("sid")

            schema = dao.get_conn_profile_key("schema")

            if oracle_database == None:
                oracle_database = ""
            if schema == None:
                schema = ""

            databases: pd.DataFrame = self._fetch_all(dao, query_string=OracleCrawler.__template_get_all_users.substitute(user=schema))
            
            databaselist = [x for x in databases['NAME']]
            for database in databaselist:
                dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})
                df_table_details: pd.DataFrame = self._fetch_all(dao,
                                                             query_string=OracleCrawler.__template_select_all_tables.substitute(
                                                                 db=oracle_database, user=database
                                                             ))
                df_table_catalog = pd.concat([df_table_catalog, df_table_details])

                df_table_summ: pd.DataFrame = self._fetch_all(dao,
                                                             query_string=OracleCrawler.__template_select_summary.substitute(
                                                                 db=oracle_database, user=database
                                                             ))
                df_table_summary = pd.concat([df_table_summary, df_table_summ])
            
            return [df_table_catalog, df_table_summary]
            # dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
            #                                             library='hdc',
            #                                             configuration={
            #                                                 'connection': self._conf['profile']})

            # # Extract the table metadata/catalog from connected Oracle source
            # oracle_database = dao.get_conn_profile_key("sid") if dao.get_conn_profile_key("sid") is not None \
            #     else dao.get_conn_profile_key("service_name")

            # df_table_catalog: pd.DataFrame = self._fetch_all(dao,
            #                                                  query_string=OracleCrawler.__template_select_all_tables.substitute(
            #                                                      db=oracle_database,
            #                                                      user=dao.get_conn_profile_key("user")
            #                                                  ))

            # return df_table_catalog

        except Exception as e:
            raise e

        return None
