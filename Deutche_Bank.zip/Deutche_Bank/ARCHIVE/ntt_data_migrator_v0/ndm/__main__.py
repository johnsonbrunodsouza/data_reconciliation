#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging.config
import warnings
from argparse import ArgumentParser, ArgumentTypeError
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
sys.path[0] = r'C:\NTTDATA\Deutche_Bank\ntt_data_migrator'
from providah.factories.package_factory import PackageFactory as providah_pkg_factory
#from ndm.core.asset_mapper import AssetMapper
from ndm.core.cataloger import Cataloger
from ndm.core.exceptions.ndm_error import NdmError
from ndm.utils import file_utils

warnings.filterwarnings("ignore")


def build_parser():
    parser = ArgumentParser(prog="ndm")

    parser.add_argument("-r", "--run", type=str, required=True, choices=['catalog'], help="'catalog'")
    parser.add_argument("-s", "--source", type=str, required=True,
                        help="Name of any one of sources configured in ndm.yml")
    parser.add_argument("-d", "--destination", type=str,
                        help="Name of any one of destinations configured in ndm.yml")
    parser.add_argument("-c", "--app_config", type=str,
                        help="Path to application config (YAML) file if other than default")
    parser.add_argument("-l", "--log_settings", type=str, help="Path to log settings (YAML) file if other than default")

    return parser


def start_here():
    ndm_parser = build_parser()
    cli_args = ndm_parser.parse_args()

    try:
        app_config: dict = file_utils.get_app_config(cli_args.app_config)

        if cli_args.log_settings is not None:
            logging.config.dictConfig(file_utils.yaml_parser(yaml_file_path=cli_args.log_settings))
        else:
            logging.config.dictConfig(file_utils.yaml_parser(yaml_file_path=file_utils.get_default_log_config_path()))

        if app_config is not None:
            if cli_args.run.lower() == 'catalog':
                try:
                    cataloger: Cataloger = providah_pkg_factory.create(key='Cataloger',
                                                                       library='ndm',
                                                                       configuration={
                                                                           'source': cli_args.source,
                                                                           'app_config': cli_args.app_config})

                    df_catalog = cataloger.obtain_catalog()

                    cataloger.pretty_print(df_catalog)

                except NdmError as ndmerror:
                    print(ndmerror)
        else:
            raise NdmError(message=f"Could not find file {app_config}")

    except ArgumentTypeError as err:
        ndm_parser.print_usage()
        raise NdmError(message=err)

    except RuntimeError as err:
        raise NdmError(message=err)


if __name__ == '__main__':
    start_here()
