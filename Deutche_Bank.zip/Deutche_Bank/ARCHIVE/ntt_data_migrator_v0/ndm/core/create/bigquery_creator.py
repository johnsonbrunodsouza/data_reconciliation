# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
#TODO: Module description
"""

from providah.factories.package_factory import PackageFactory as providah_pkg_factory

from ndm.core.create.rdbms_creator import RdbmsCreator
from ndm.core.dao.rdbms_dao import RdbmsDAO


class BigQueryCreator(RdbmsCreator):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def replicate_structures(self, sql_ddl_list):
        try:

            dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})
            self._execute_update(dao, sql_ddl_list)

        except:
            raise

    def _execute_update(self, dao, sql_ddl_list):
        ### dao object is not being as it does not have query() method
        from google.cloud import bigquery
        import yaml
        import os
        from pathlib import Path

        yaml_file_path = Path.home() / '.hdc' / 'profile.yml'
        
        service_account_key_path = ''
        project_id = ''
        with open(yaml_file_path, 'r') as stream:
            config = yaml.safe_load(os.path.expandvars(stream.read()))
            service_account_key_path = config['bigquery']['client_service_json'].split('.json')[0] + '.json' # this is because path is appended with datetime. need to fix that
            project_id = config['bigquery']['dataset']

       
        #service_account_key_path = r"C:\NTTDATA\Deutche_bank\bigquery-eval-hd1341-f4215fb67922.json"
        #project_id = "bigquery-eval-hd1341"
        client = bigquery.Client.from_service_account_json(service_account_key_path, project=project_id)
        

        # for dataset in datasets:
        #     client.create_dataset(dataset.lower(),exists_ok=True)

        for create_query in sql_ddl_list:
            create_query = create_query.lower()
            query = create_query
            print(create_query)
            try:
                client.query(create_query)
            except Exception as e:
                print(f"Could not not execute SQL: [{query}]")
                print(f'Reason: [{e}]')
