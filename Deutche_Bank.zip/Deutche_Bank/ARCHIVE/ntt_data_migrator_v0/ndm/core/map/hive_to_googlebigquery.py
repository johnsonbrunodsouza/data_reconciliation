#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import pandas as pd

from hdc.core.map.mapper import Mapper
import re
from google.cloud import bigquery
import yaml
import os
from pathlib import Path

class HiveToBigQuery(Mapper):
    data_type_map = { 
            "int64": "int|tinyint|smallint|bigint|integer",
            "numeric":"decimal",
            "float64":"double|float",
            "bool":"boolean",
            "string":"char|string|varchar",
            "bytes":"binary",
            "date": "date",
            "datetime":"timestamp",
            "array":"array",
            "struct":"struct|maps|union",
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def map_assets(self, df_catalog: pd.DataFrame) -> list:
        yaml_file_path = Path.home() / '.hdc' / 'profile.yml'
        
        service_account_key_path = ''
        project_id = ''
        with open(yaml_file_path, 'r') as stream:
            config = yaml.safe_load(os.path.expandvars(stream.read()))
            service_account_key_path = config['bigquery']['client_service_json'].split('.json')[0] + '.json' # this is because path is appended with datetime. need to fix that
            project_id = config['bigquery']['dataset']

        databases = df_catalog['DATABASE_NAME'].unique().tolist()

        sql_ddl_list = []
        sql_ddl_list = self.__map_schemas(project_id,databases)
        sql_ddl_list.extend(self.__map_tables(df_catalog))

        if self._conf.get("report", False):
            self._build_report(df_catalog)

        return sql_ddl_list

    @staticmethod
    def __map_databases(databases) -> list:
        return [f'CREATE SCHEMA IF NOT EXISTS `{db.upper()}`' for db in databases]

    @staticmethod
    def __map_schemas(database, schemas) -> list:
        return [f'CREATE SCHEMA IF NOT EXISTS `{database}.{schema}`' for schema in schemas]

    @staticmethod
    def __map_data_types(group_df):
        result = []
        primary_key_set = set()
        foreign_key_set = set()
        parent_table_set = set()

        for (column_name, column_type, is_not_null, primary_key, foreign_key, parent_table) in zip(list(group_df['COLUMN_NAME']),
                                                           list(group_df['COLUMN_TYPE']), 
                                                           list(group_df['NOT_NULL']), 
                                                           list(group_df['PRIMARY_KEY']),
                                                           list(group_df['FOREIGN_KEY']),
                                                           list(group_df['PARENT_TABLE'])): 
            column_type = column_type.replace(':',' ').replace('<',' < ').replace('>',' > ').replace(',',' , ')
            for target_type, source_type in HiveToBigQuery.data_type_map.items():
                for s_type in source_type.split('|'):
                    tokens = []
                    for s in column_type.split(' '):
                        if s_type == s:
                            tokens.append(target_type)
                        else:
                            tokens.append(s)
                    column_type = ' '.join(tokens) 
            if is_not_null.lstrip().rstrip().upper() == 'Y':
                result.append(f'{column_name} {column_type} NOT NULL')
            else:
                result.append(f'{column_name} {column_type}')
            if primary_key is not None:
                primary_key_set.add(str(primary_key))
            
            if foreign_key is not None:
                foreign_key_set = {f_key for f_key in str(foreign_key).split('#')}
                parent_table_set.add(str(parent_table))
        
        if len(primary_key_set)>0:
            p_keys = f','.join(list(primary_key_set))
            result.append(f'PRIMARY KEY ({p_keys}) NOT ENFORCED')

        return f','.join(result),list(primary_key_set),list(foreign_key_set),list(parent_table_set)

    def __map_tables(self, df_catalog: pd.DataFrame) -> list:
        sql_ddl = []
        df_catalog['COLUMN_TYPE'] = df_catalog['COLUMN_TYPE'].apply(lambda x: x.lower())
        df_catalog['COLUMN_DESC'] = df_catalog['COLUMN_NAME'] + '|' + df_catalog['COLUMN_TYPE']
        df_table_group = df_catalog[['DATABASE_NAME', 'TABLE_NAME','COLUMN_NAME', 'COLUMN_TYPE','COLUMN_DESC','NOT_NULL','PRIMARY_KEY','FOREIGN_KEY', 'PARENT_TABLE']].groupby(
            ['DATABASE_NAME', 'TABLE_NAME'])
        
        create_or_replace_not_exists = ""
        if self._conf.get("recreate", True):
            create_or_replace_not_exists = "CREATE OR REPLACE TABLE"
        else:
            create_or_replace_not_exists = "CREATE TABLE IF NOT EXISTS"

        primary_key_tables = {}
        foreign_key_tables = {}

        for name, group_df in df_table_group:
            #columns = self.create_column_type(group_df)
            columns, primary_keys, foreign_key, parent_table  = self.__map_data_types(group_df)
            sql_ddl.append(f"{create_or_replace_not_exists} {'.'.join(name)} "
                           f"( {columns} )")
            
            if len(primary_keys)>0:
                primary_key_tables[f'{name[0]}.{name[1]}'] = primary_keys

            if len(foreign_key)>0:
                foreign_key_tables[f'{name[0]}.{name[1]}'] = (f'{name[0]}.{parent_table[0]}', foreign_key)

        #print(f'primary_key_tables:{primary_key_tables}, foreign_key_tables:{foreign_key_tables}')
        sql_ddl.extend(self.__create_foreign_key_mapping(foreign_key_tables,primary_key_tables))

        return sql_ddl

    def __create_foreign_key_mapping(self, foreign_key_tables,primary_key_tables):
        alter_table_fk = []

        for table_name, param in foreign_key_tables.items():
            for composite_name in param[1]:
                vals = composite_name.split('-')
                fk_constraint = vals[0]
                fk_key = vals[1]
                if param[0] in primary_key_tables: ## if primary key table is found--investigate
                    alter_st = f'ALTER TABLE `{table_name}` ADD CONSTRAINT {fk_constraint} FOREIGN KEY ({fk_key})  REFERENCES `{param[0]}`({primary_key_tables[param[0]][0]}) NOT ENFORCED'
                    #print(alter_st)
                    alter_table_fk.append(alter_st)

        return alter_table_fk

    
    def create_column_type(self, group_df):
        result = []
        primary_key_set = set()

        for (column_name, column_type, is_not_null, primary_key) in zip(list(group_df['COLUMN_NAME']),  ## foreign_key
                                                           list(group_df['COLUMN_TYPE']), 
                                                           list(group_df['NOT_NULL']), 
                                                           list(group_df['PRIMARY_KEY'])): ## list(group_df['FOREIGNKEY'])
            column_type = column_type.replace(':',' ').replace('<',' < ').replace('>',' > ').replace(',',' , ')
            for target_type, source_type in HiveToBigQuery.data_type_map.items():
                for s_type in source_type.split('|'):
                    tokens = []
                    for s in column_type.split(' '):
                        if s_type == s:
                            tokens.append(target_type)
                        else:
                            tokens.append(s)
                    column_type = ' '.join(tokens) 
            if is_not_null.lstrip().rstrip().upper() == 'Y':
                result.append(f'{column_name} {column_type} NOT NULL')
            else:
                result.append(f'{column_name} {column_type}')
            if primary_key is not None:
                primary_key_set.add(str(primary_key))
        
        if len(primary_key_set)>0:
            p_keys = f','.join(list(primary_key_set))
            result.append(f'PRIMARY KEY ({p_keys}) NOT ENFORCED')

        return f','.join(result) 
