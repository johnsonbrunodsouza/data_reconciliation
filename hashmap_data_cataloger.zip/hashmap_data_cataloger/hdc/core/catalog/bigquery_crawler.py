# Copyright © 2020 Hashmap, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from string import Template 

import pandas as pd
from providah.factories.package_factory import PackageFactory as providah_pkg_factory

from hdc.core.catalog.rdbms_crawler import RdbmsCrawler
from hdc.core.dao.rdbms_dao import RdbmsDAO
import json

class BigQueryCrawler(RdbmsCrawler):
    __template_select_all_tables = Template("""
                                                select 
                                                    t.table_catalog as DATABASE_NAME,
                                                    t.table_Schema as SCHEMA_NAME,
                                                    t.table_name as TABLE_NAME,
                                                    c.column_name as COLUMN_NAME,
                                                    REGEXP_REPLACE(c.data_type, r'\(.*\)', '') as COLUMN_TYPE,
                                                    case 
                                                      when UPPER(REGEXP_REPLACE(c.data_type, r'\(.*\)', '')) in ('NUMERIC','DECIMAL') and regexp_substr(c.data_type, r'\(.*\)', 1,1) is null then '(38,9)'
                                                      when UPPER(REGEXP_REPLACE(c.data_type, r'\(.*\)', '')) in ('BIGNUMERIC','BIGDECIMAL') and regexp_substr(c.data_type, r'\(.*\)', 1,1) is null then '(38,19)'
                                                      else regexp_substr(c.data_type, r'\(.*\)', 1,1) 
                                                    end as COLUMN_SIZE,
                                                    c.is_nullable as NOT_NULL,
                                                    c.column_default as DEFAULT_VALUE,
                                                    comm.description as COMMENT_STRING,
                                                    '' as CHARACTER_SET_NAME,
                                                    c.collation_name as COLLATION_NAME
                                                from $dataset.INFORMATION_SCHEMA.TABLES t
                                                inner join $dataset.INFORMATION_SCHEMA.COLUMNS c
                                                    on t.table_catalog = c.table_catalog
                                                    and t.table_schema = c.table_schema
                                                    and t.table_name = c.table_name
                                                left join $dataset.INFORMATION_SCHEMA.COLUMN_FIELD_PATHS comm
                                                    on comm.table_catalog = c.table_catalog
                                                    and comm.table_schema = c.table_schema
                                                    and comm.table_name = c.table_name
                                                    and comm.column_name = c.column_name
                                                where t.table_catalog = '$db' 
                                                order by t.table_schema, t.table_name, c.ordinal_position                                               
                                            """)
    
    __template_select_summary = Template("""
                                            with summ as (
                                                select
                                                    t.table_catalog as DatabaseName,
                                                    t.table_Schema as SchemaName,
                                                    t.table_name as TableName,
                                                    t.table_type as TableType,
                                                    '' as PrimaryKey,
                                                    '' as ForeignKey
                                                from $dataset.INFORMATION_SCHEMA.TABLES t
                                                where t.table_catalog = '$db' 
                                                and t.table_type = 'BASE TABLE'
                                            ),
                                            indexes as (
                                                select
                                                    index_catalog as DatabaseName,
                                                    index_schema as SchemaName,
                                                    table_name as TableName,
                                                    index_name || STRING_AGG(index_column_name) as IndexColumns
                                                from $dataset.INFORMATION_SCHEMA.SEARCH_INDEX_COLUMNS
                                                group by index_catalog, index_schema, table_name, index_name
                                            ),
                                            metrics as (
                                                select 
                                                    project_id as DatabaseName,
                                                    dataset_id as SchemaName,
                                                    table_id as TableName,
                                                    row_count as RowCount,
                                                    size_bytes/pow(10,2) as TableSizeInMb,
                                                    datetime(TIMESTAMP_MILLIS(last_modified_time)) as LastModified,
                                                    '' as LastAccessed,
                                                    'N' as TriggerPresent
                                                from $dataset.__TABLES__
                                            ),
                                            columnmetrics as (
                                                select
                                                    table_catalog as DatabaseName,
                                                    table_schema as SchemaName,
                                                    table_name as TableName,
                                                    count(*) as ColumnCount
                                                from $dataset.INFORMATION_SCHEMA.COLUMNS
                                                group by table_catalog, table_schema, table_name
                                            ),
                                            tableoptions as (
                                                select
                                                    table_catalog as DatabaseName,
                                                    table_Schema as SchemaName,
                                                    table_name as TableName,
                                                    OPTION_VALUE as Comments
                                                from $dataset.INFORMATION_SCHEMA.TABLE_OPTIONS
                                                where OPTION_NAME = 'description'
                                            ),
                                            probablewatermarks as (
                                                select
                                                    table_catalog as DatabaseName,
                                                    table_schema as SchemaName,
                                                    table_name as TableName,
                                                    STRING_AGG(column_name) as ProbableWatermarkColumns
                                                from $dataset.INFORMATION_SCHEMA.COLUMNS
                                                where REGEXP_REPLACE(data_type ,r'\(.*\)',"") in ('DATETIME', 'TIMESTAMP')
                                                group by table_catalog, table_schema, table_name
                                            ),
                                            partitions as (
                                                select
                                                    table_catalog as DatabaseName,
                                                    table_schema as SchemaName,
                                                    table_name as TableName,
                                                    STRING_AGG(column_name) as PartitionColumn
                                                from $dataset.INFORMATION_SCHEMA.COLUMNS
                                                where is_partitioning_column = 'YES'
                                                group by table_catalog, table_schema, table_name
                                            )
                                                select
                                                    summ.DatabaseName,
                                                    summ.SchemaName,
                                                    summ.TableName,
                                                    summ.PrimaryKey,
                                                    summ.ForeignKey,
                                                    i.IndexColumns,
                                                    m.RowCount,
                                                    coalesce(cm.ColumnCount,0) as ColumnCount,
                                                    m.TableSizeInMb,
                                                    top.Comments,
                                                    pw.ProbableWatermarkColumns,
                                                    m.TriggerPresent,
                                                    pa.PartitionColumn,
                                                    m.LastAccessed,
                                                    m.LastModified
                                                from summ 
                                                left join indexes i
                                                    on summ.DatabaseName = i.DatabaseName
                                                    and summ.SchemaName = i.SchemaName
                                                    and summ.TableName = i.TableName
                                                left join metrics m
                                                    on summ.DatabaseName = m.DatabaseName
                                                    and summ.SchemaName = m.SchemaName
                                                    and summ.TableName = m.TableName
                                                left join columnmetrics cm
                                                    on summ.DatabaseName = cm.DatabaseName
                                                    and summ.SchemaName = cm.SchemaName
                                                    and summ.TableName = cm.TableName
                                                left join tableoptions top
                                                    on summ.DatabaseName = top.DatabaseName
                                                    and summ.SchemaName = top.SchemaName
                                                    and summ.TableName = top.TableName
                                                left join probablewatermarks pw
                                                    on summ.DatabaseName = pw.DatabaseName
                                                    and summ.SchemaName = pw.SchemaName
                                                    and summ.TableName = pw.TableName
                                                left join partitions pa
                                                    on summ.DatabaseName = pa.DatabaseName
                                                    and summ.SchemaName = pa.SchemaName
                                                    and summ.TableName = pa.TableName;                                            
    """
    )

    # __template_get_all_datasets = Template("""
    #                                             SELECT
    #                                                 schema_name
    #                                             FROM $db.`region-$region`.INFORMATION_SCHEMA.SCHEMATA;
                                                
    # """
    # )

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def obtain_catalog(self) -> pd.DataFrame:
        try:                                   
            df_table_catalog = pd.DataFrame()
            df_table_summary = pd.DataFrame() 
            specificdataset = ""
            dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})
            
            # Extract the table metadata/catalog from connected SQL source
            with open(dao.get_conn_profile_key("client_service_json"), "r") as fileobj:
                bq_database = json.load(fileobj)['project_id']
            # bq_database = dao.get_conn_profile_key("service_json")
            if bq_database == None:
                bq_database = ""
            
            specificdataset = dao.get_conn_profile_key("dataset", "")            

            dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile'], 'database': bq_database})
            with dao.get_connection() as conn:
                datasetslist = conn.list_datasets()

            for dataset in datasetslist:
                # dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                #                                         library='hdc',
                #                                         configuration={
                #                                             'connection': self._conf['profile'], 'database': bq_database})
                if specificdataset == dataset.dataset_id or specificdataset == "": 
                    df_table_details: pd.DataFrame = self._fetch_all(dao,query_string=BigQueryCrawler.__template_select_all_tables.substitute(db=bq_database,dataset=dataset.dataset_id),alternate_executor='GCP')
                    df_table_catalog = pd.concat([df_table_catalog, df_table_details])

                    df_table_summ: pd.DataFrame = self._fetch_all(dao,query_string=BigQueryCrawler.__template_select_summary.substitute(db=bq_database,dataset=dataset.dataset_id),alternate_executor='GCP')
                    df_table_summary = pd.concat([df_table_summary, df_table_summ])
            
            return [df_table_catalog, df_table_summary]

        except Exception as e:
            raise e

        return None
