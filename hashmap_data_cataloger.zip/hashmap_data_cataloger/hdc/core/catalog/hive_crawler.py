#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
from string import Template

import pandas as pd
from providah.factories.package_factory import PackageFactory as providah_pkg_factory

from hdc.core.catalog.rdbms_crawler import RdbmsCrawler
from hdc.core.dao.rdbms_dao import RdbmsDAO
import streamlit as st


class HiveCrawler(RdbmsCrawler):
    _e_select_all_databases = Template("SELECT DISTINCT NAME FROM DBS WHERE NAME = '$db_name'")
    __template_select_all_tables = Template("SELECT d.NAME as DATABASE_NAME, "
                                            "'$schema_name' as SCHEMA_NAME, "
                                            "t.TBL_NAME as TABLE_NAME, "
                                            "c.COLUMN_NAME as COLUMN_NAME, "
                                            "c.TYPE_NAME as COLUMN_TYPE, "
                                            "t.TBL_TYPE as TABLE_TYPE, "
                                            "d.DB_LOCATION_URI as DB_LOCATION, "
                                            "d.OWNER_NAME as OWNER_NAME, "
                                            "p.PKEY_NAME as PARTITION_KEY_NAME "
                                            "FROM hive.TBLS t "
                                            "JOIN hive.DBS d "
                                            "ON t.DB_ID = d.DB_ID "
                                            "JOIN hive.SDS s "
                                            "ON t.SD_ID = s.SD_ID "
                                            "JOIN hive.COLUMNS_V2 c "
                                            "ON s.CD_ID = c.CD_ID "
                                            " LEFT JOIN hive.PARTITION_KEYS p on p.TBL_ID = t.TBL_ID "
                                            #"WHERE d.NAME='$db_name' "
                                            "ORDER by d.NAME,t.TBL_NAME,c.INTEGER_IDX")
    
# SELECT d.NAME as DATABASE_NAME, 'default' as SCHEMA_NAME, t.TBL_NAME as TABLE_NAME, c.COLUMN_NAME as COLUMN_NAME, c.TYPE_NAME as COLUMN_TYPE,  d.DB_LOCATION_URI as DB_LOCATION,  d.OWNER_NAME as OWNER_NAME, p.PKEY_NAME as PARTITION_KEY_NAME FROM hive.TBLS t JOIN hive.DBS d ON t.DB_ID = d.DB_ID JOIN hive.SDS s ON t.SD_ID = s.SD_ID JOIN hive.COLUMNS_V2 c ON s.CD_ID = c.CD_ID LEFT JOIN hive.PARTITION_KEYS p on p.TBL_ID = t.TBL_ID  ORDER by d.NAME,t.TBL_NAME,c.INTEGER_IDX;

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def obtain_catalog(self) -> pd.DataFrame:
        try:
            dao: RdbmsDAO = providah_pkg_factory.create(key=self._conf['type'].capitalize(),
                                                        library='hdc',
                                                        configuration={
                                                            'connection': self._conf['profile']})
            df_table_catalog: pd.DataFrame = self._fetch_all(dao,
                                                             query_string=HiveCrawler.__template_select_all_tables.substitute(
                                                                 schema_name='default',
                                                                 db_name=dao.get_conn_profile_key('database')))
            # # df_table_catalog: pd.DataFrame = self._fetch_all(dao,
            # #                                                  query_string="SHOW DATABASES")
            
            # # st.dataframe(df_table_catalog)
            
            # result = self.fetch_databases(dao=dao)
            # self.fetch_tablenames(dao, result)

            # df_table_catalog = pd.DataFrame()
            
            if not df_table_catalog.empty:
                # This had to be re-applied because the query alias doesnt seem to be working.
                # Please do not remove below mapping.
                df_table_catalog.columns = ['DATABASE_NAME', 'SCHEMA_NAME', 'TABLE_NAME', 'COLUMN_NAME', 'COLUMN_TYPE', 'TABLE_TYPE','DB_LOCATION','OWNER_NAME','PARTITION_KEY_NAME']

            return df_table_catalog
        except Exception as e:
            raise e

        return None
    def fetch_databases(self, dao):
        with dao.get_connection() as conn:                
            cursor = conn.cursor()
            cursor.execute("SHOW DATABASES")
            db_list = cursor.fetchall()
            return db_list
    def fetch_tablenames(self, dao, list_db):
        try:

            print("############")
            print(list_db)
            print("############")

            with dao.get_connection() as conn:                
                cursor = conn.cursor()
                for db in list_db:
                    print("___________")
                    print(db[0])
                    print("___________")
                    cursor.execute(f"USE {db[0]}")
                    print("done a")
                    #cursor.fetchall()
                    print("done b")
                    cursor.execute("SHOW TABLES")
                    print("done c")
                    table_list = cursor.fetchall()
                    for table in table_list:
                        cursor.execute(f"DESCRIBE FORMATTED {table[0]}")
                        desc_list = cursor.fetchall()
                        print(desc_list)
                        st.dataframe(desc_list)

        except Exception as exc:
            print("((((((((((((((((((()))))))))))))))))))")
            print(exc)
            print("((((((((((((((((((()))))))))))))))))))")

            
        
            # for db in db_list:
            #     print("*****************")
            #     print(db)
            #     print("*****************")
            #     cursor = conn.cursor()
            #     cursor.execute(f"USE {db[0]}")
            #     cursor.fetchall()
            #     cursor.execute("SHOW TABLES")
            #     table_list = cursor.fetchall()
            #     st.info(table_list)    