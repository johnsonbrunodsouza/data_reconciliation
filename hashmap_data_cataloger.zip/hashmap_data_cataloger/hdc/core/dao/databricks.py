#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

from hdc.core.dao.odbc_connector import OdbcConnector
from hdc.core.dao.rdbms_dao import RdbmsDAO

from databricks import sql as databrickssql

class DatabricksDAO(RdbmsDAO):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def _attempt_to_connect(self, connection_profile):
        return self.__databricks_connector(connection_profile) 

    def _test_connection(self, connection) -> bool:
        """
        Validate that the connection is valid to Snowflake instance

        Returns: True if connection is valid, False otherwise

        """
        if not connection:
            return False

        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            if not len(cursor.fetchone()) > 0:
                return False

            return True           

    @staticmethod
    def __databricks_connector(connection_profile):
        base_keys_validation_output = RdbmsDAO._validate_connection_profile(connection_profile, ['http_path', 'server_hostname', 'token'])

        if not base_keys_validation_output[0]:
            raise KeyError(
                f'One or more of {base_keys_validation_output[1]} keys not configured in profile')

        return databrickssql.connect(server_hostname = connection_profile['server_hostname'],
                                     http_path = connection_profile['http_path'],
                                     access_token = connection_profile['token'])