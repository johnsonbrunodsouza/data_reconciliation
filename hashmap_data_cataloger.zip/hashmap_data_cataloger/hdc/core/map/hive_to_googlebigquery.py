#  Copyright © 2020 Hashmap, Inc
#  #
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#  #
#      http://www.apache.org/licenses/LICENSE-2.0
#  #
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import pandas as pd

from hdc.core.map.mapper import Mapper
import re

class HiveToBigQuery(Mapper):
    data_type_map = { 
        ### integer types
        "INT64":"int|tinyint|smallint|integer",
        "numeric":"float",
        "bignumeric":"double|decimal",
        ### char types
        "string":"char|varchar",
        ### misc types
        "bool":"boolean",        
        "bytes":"binary",        
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.__logger = self._get_logger()

    def map_assets(self, df_catalog: pd.DataFrame) -> list:
        unique_databases = df_catalog['DATABASE_NAME'].unique()

        # DDL for all unique databases
        datasets = unique_databases.tolist()
        sql_ddl_list = []
        sql_ddl_list = self.create_table_script(df_catalog)

        if self._conf.get("report", False):
            self._build_report(df_catalog)

        self.create_db_objects(datasets, sql_ddl_list)

        return sql_ddl_list

    @staticmethod
    def __map_databases(databases) -> list:
        return [f'CREATE SCHEMA IF NOT EXISTS `{db.upper()}`' for db in databases]

    @staticmethod
    def __map_schemas(database, schemas) -> list:
        return [f'CREATE SCHEMA IF NOT EXISTS `{database.upper()}.{schema.upper()}`' for schema in schemas]

    @staticmethod
    def __map_data_types(src_data_type: pd.Series) -> pd.Series:
        """
        Return a new pd.Series which has converted source data types to target data types for those found in the
        class's data_type_map; replace all else (not found in the map) with a hyphen '-'

        :param src_data_type:
        :return: pd.Series
        """
        keep = '|'.join(HiveToBigQuery.data_type_map.values())
        discard = rf"(?!{keep})"
        supported_data_type = src_data_type.str.match(keep)
        unsupported_data_type = src_data_type.str.match(discard)
        target_data_type = src_data_type[supported_data_type]
        for target_type, source_type in HiveToBigQuery.data_type_map.items():
            target_data_type = target_data_type.str.replace(source_type, target_type, case=False)

        return pd.concat([
            target_data_type,
            src_data_type[unsupported_data_type].str.replace(':',',').replace('.*', '-', regex=True)
        ])

    def __map_tables(self, df_catalog: pd.DataFrame) -> list:
        sql_ddl = []
        #df_catalog['COLUMN_TYPE'] = df_catalog['COLUMN_TYPE'].apply(lambda x: x.upper()) #MRD making the data types upper case
        df_catalog['COLUMN_TYPE'] = df_catalog['COLUMN_TYPE'].apply(lambda x: x.lower()) #MRD making the data types upper case
        df_catalog['TARGET_COLUMN_TYPE'] = self.__map_data_types(df_catalog['COLUMN_TYPE'])

        df_catalog['COLUMN_DESC'] = df_catalog['COLUMN_NAME'] + ' ' + df_catalog['TARGET_COLUMN_TYPE']

        df_table_group = df_catalog[
            ['DATABASE_NAME', 'TABLE_NAME', 'TARGET_COLUMN_TYPE', 'COLUMN_DESC']].groupby(
            ['DATABASE_NAME', 'TABLE_NAME'])

        for name, group_df in df_table_group:
            sql_ddl.append(f"CREATE OR REPLACE TABLE {'.'.join(name).upper()} "
                           f"("
                           f"{','.join(list(group_df[~group_df['TARGET_COLUMN_TYPE'].str.contains('-')]['COLUMN_DESC'])).upper()}"
                           #f", CK_SUM VARCHAR"
                           f")")

        return sql_ddl
    
    def create_table_script(self, df_catalog: pd.DataFrame) -> list:
        sql_ddl = []
        df_catalog['COLUMN_TYPE'] = df_catalog['COLUMN_TYPE'].apply(lambda x: x.lower())
        df_catalog['COLUMN_DESC'] = df_catalog['COLUMN_NAME'] + '|' + df_catalog['COLUMN_TYPE']
        df_table_group = df_catalog[['DATABASE_NAME', 'TABLE_NAME','COLUMN_NAME', 'COLUMN_TYPE','COLUMN_DESC','NOT_NULL']].groupby(
            ['DATABASE_NAME', 'TABLE_NAME'])

        for name, group_df in df_table_group:
            columns = self.create_column_type(group_df)
            sql_ddl.append(f"CREATE OR REPLACE TABLE {'.'.join(name)} "
                           f"( {columns} )")
        return sql_ddl
    
    def create_column_type(self, group_df):
        result = []
        for (column_name, column_type, is_not_null) in zip(list(group_df['COLUMN_NAME']), list(group_df['COLUMN_TYPE']), list(group_df['NOT_NULL'])):
            column_type = column_type.replace(':',' ').replace('<',' < ').replace('>',' > ').replace(',',' , ')
            for target_type, source_type in HiveToBigQuery.data_type_map.items():
                for s_type in source_type.split('|'):
                    tokens = []
                    for s in column_type.split(' '):
                        if s_type == s:
                            tokens.append(target_type)
                        else:
                            tokens.append(s)
                    column_type = ' '.join(tokens) 
            if is_not_null.lstrip().rstrip().upper() == 'Y':
                result.append(f'{column_name} {column_type} NOT NULL')
            else:
                result.append(f'{column_name} {column_type}')

        return f','.join(result) 

    def create_db_objects(self,datasets, sql_ddl_list):
        from google.cloud import bigquery
        import yaml
        import os
        from pathlib import Path

        yaml_file_path = Path.home() / '.hdc' / 'profile.yml'
        
        service_account_key_path = ''
        with open(yaml_file_path, 'r') as stream:
            config = yaml.safe_load(os.path.expandvars(stream.read()))
            service_account_key_path = config['bigquery']['client_service_json'].split('.json')[0] + '.json' # this is because path is appended with datetime. need to fix that
       
        #service_account_key_path = r"C:\NTTDATA\Deutche_bank\bigquery-eval-hd1341-f4215fb67922.json"
        project_id = "bigquery-eval-hd1341"
        client = bigquery.Client.from_service_account_json(service_account_key_path, project=project_id)

        for dataset in datasets:
            client.create_dataset(dataset.lower(),exists_ok=True)

        for create_query in sql_ddl_list:
            create_query = create_query.lower()
            query = create_query
            print(create_query)
            try:
                client.query(create_query)
            except Exception as e:
                print(f'***{query}')    
    
    def store_dataframe(self,df):
        from google.cloud import bigquery
        import yaml
        import os
        from pathlib import Path
        yaml_file_path = Path.home() / '.hdc' / 'profile.yml'
        
        service_account_key_path = ''
        with open(yaml_file_path, 'r') as stream:
            config = yaml.safe_load(os.path.expandvars(stream.read()))
            service_account_key_path = config['bigquery']['client_service_json'].split('.json')[0] + '.json' # this is because path is appended with datetime. need to fix that
       
        # = r"C:\NTTDATA\Deutche_bank\bigquery-eval-hd1341-f4215fb67922.json"
        project_id = "bigquery-eval-hd1341"
        client = bigquery.Client.from_service_account_json(service_account_key_path, project=project_id)

        job_config = bigquery.LoadJobConfig(
        schema=[
                bigquery.SchemaField("DATABASE_NAME", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("TABLE_NAME", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("TABLE_TYPE", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("COLUMN_NAME", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("COLUMN_TYPE", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("CREATE_TIME", bigquery.enums.SqlTypeNames.DATETIME),
                bigquery.SchemaField("LAST_ACCESS_TIME", bigquery.enums.SqlTypeNames.DATETIME),
                bigquery.SchemaField("PARTITION_KEY_NAME", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("PARTITION_KEY_TYPE", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("BUCKET_COL_NAME", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("DB_LOCATION", bigquery.enums.SqlTypeNames.STRING),
                bigquery.SchemaField("OWNER_NAME", bigquery.enums.SqlTypeNames.STRING),
        ],
        write_disposition="WRITE_TRUNCATE", )

        table_id = f'{project_id}.statemanager.hive_structure'
        job = client.load_table_from_dataframe(df, table_id, job_config=job_config)
        job.result()
        table = client.get_table(table_id)  # Make an API request.
        print("Loaded {} rows and {} columns to {}".format(table.num_rows, len(table.schema), table_id))     
